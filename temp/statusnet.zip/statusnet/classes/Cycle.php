<?php
/**
 * Table Definition for avatar
 */
require_once INSTALLDIR.'/classes/Memcached_DataObject.php';

class Cycle extends Managed_DataObject
{
    ###START_AUTOCODE
    /* the code below is auto generated do not remove the above tag */

    public $__table = 'cycle';              // table name
    public $id;
    public $nickname;                      // int(4)  primary_key not_null
    public $owner_id;                      // int(4)  primary_key not_null
    public $created;                         // datetime()   not_null
    public $modified;                        // timestamp()   not_null default_CURRENT_TIMESTAMP

    /* Static get */
    function staticGet($k,$v=null)
    { return Memcached_DataObject::staticGet('Cycle',$k,$v); }

    

	static function pivotGet($keyCol, $keyVals, $otherCols)
	{
	    return Memcached_DataObject::pivotGet('Cycle', $keyCol, $keyVals, $otherCols);
	}
	
    public static function schemaDef()
    {
        return array(
            'fields' => array(
                'id' => array('type' => 'int', 'not null' => true, 'description' => ''),
                'nickname' => array('type' => 'varchar', 'length' => 255, 'description' => ''),
                'owner_id' => array('type' => 'int', 'length' => 11, 'description' => ''),
                'created' => array('type' => 'datetime', 'not null' => true, 'description' => 'date this record was created'),
                'modified' => array('type' => 'timestamp', 'not null' => true, 'description' => 'date this record was modified'),
            ),
        	'primary key' => array('id'),
            'indexes' => array(
                'cycle_idx' => array('id'),
            ),
        );
    }
    

        function getOneInf($group_id)
        {
        	$cycle=new cycle();
        	$cycle->get('id',$group_id);
        	$cycle_member=new Cycle_member();
        	$person=$cycle_member->getMember($group_id);
        	return array('persons'=>$person,
                         'group_id' => $cycle->id,
						'name' => $cycle->nickname,
						'owner_id' => $cycle->owner_id,
						'created' => $cycle->created 
		);
	}

    /**
     * Where should the avatar go for this user?
     */
    

    
}
