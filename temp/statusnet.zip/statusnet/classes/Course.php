<?php

if (!defined('STATUSNET')) {
	exit(1);
}

/**
 * Table Definition for course
 */

require_once INSTALLDIR.'/classes/Memcached_DataObject.php';

class Course extends Managed_DataObject
{
	###START_AUTOCODE
	/* the code below is auto generated do not remove the above tag */

	public $__table = 'Course';             // table name
	public $id;                      		// int primary_key not_null
	public $nickname;                       // varchar(64)  
	public $fullname;                     	// varchar(255)
	public $description;					// text
	public $type;							// tinyint
	public $applicable_grades;				// int
	public $created;                         // datetime   not_null default_0000-00-00%2000%3A00%3A00
	public $modified;                         // datetime   not_null default_0000-00-00%2000%3A00%3A00

	/* Static get */
	function staticGet($k,$v=NULL) { return Memcached_DataObject::staticGet('Course',$k,$v); }

	/* the code above is auto generated do not remove the tag below */
	###END_AUTOCODE
	
	const REGULAR 	=	1;					// 常规课程
	const SEMINAR 	=	2;					// 讲座
	const WORKSHOP 	= 	3;					// 工作坊

	public static function schemaDef()
	{
		return array(
				'fields' => array(
						'id' => array('type' => 'serial', 'not null' => true, 'description' => 'unique identifier'),
						'nickname' => array('type' => 'varchar', 'length' => 64, 'not null' => false, 'description' => 'course code'),
						'fullname' => array('type' => 'varchar', 'length' => 255, 'not null' => false, 'description' => 'course full name'),
						'description' => array('type' => 'text', 'not null' => false, 'description' => 'course description'),
						'type' => array('type' => 'tinyint', 'length' => 4, 'not null' => false, 'description' => 'type of the course'),
						'applicable_grades' => array('type' => 'int', 'not null' => false, 'description' => 'grades the course is applied to'),
						'created' => array('type' => 'datetime', 'not null' => true, 'description' => 'date the role was granted'),
						'modified' => array('type' => 'timestamp', 'not null' => true, 'description' => 'date the role was granted')
				),
				'primary key' => array('id'),
				'foreign keys' => array(),
				'indexes' => array(
						'course_nickname_idx' => array('nickname'),
						'course_fullname_idx' => array('fullname'),
						),
		);
	}

	function pkeyGet($kv)
	{
		return Memcached_DataObject::pkeyGet('Course', $kv);
	}
	
	function find()
	{
		common_link_db();
		$sql="select nickname,fullname,type,id from course";
		$res=mysql_query($sql);
		$course=array();
		while($arr=mysql_fetch_array($res)){
			$course[]=$arr;
		}
		return $course;
	}
	function findChangGui($type)
	{
		common_link_db();
	 	  $sql="select nickname,fullname,type,id from course where type=".$type;
		$res=mysql_query($sql);
		$course=array();
		while($arr=mysql_fetch_array($res)){
			 $course_inner=array('id1'=>$arr['id'],'nickname1'=>$arr['nickname']);
			 $course[]=$course_inner;
		 }
		return $course;
	}
 
	
	function findone($id)
	{
		common_link_db();
		$sql="select * from course where id=".$id;
		$res=mysql_query($sql);
		if($oneCourse=mysql_fetch_array($res)){
		  switch ($oneCourse['type'])
		  {
		  	case 1:
		  		$oneCourse['type']="常规课";
		  		break;
		  	case 3:
		  		$oneCourse['type']="一次性课程";
		  		break;
		  		
		  }
		  return $oneCourse;
		}
	}
	
	function updataCourse($course)
	{
		 
	      common_link_db();
	      $created=common_sql_now();
	         $sql="UPDATE `statusnet`.`course` SET 
				`fullname` = '$course[0]',
				`description` = '$course[1]',
				`type` = '$course[2]',
				`applicable_grades` = '$course[3]',`created` = '$created' WHERE `course`.`id` =$course[4];";
	    $res=mysql_query($sql);
	}
	
	function delteCourse($id)
	{
		common_link_db();
	    $sql="DELETE FROM `statusnet`.`course` WHERE `course`.`id` = ".$id;
	    $res=mysql_query($sql);
	}
	
	function  addcourse($data)
	{
	
		common_link_db();
		$created=common_sql_now();
		$mysql="INSERT INTO `statusnet`.`course` (`id`, `nickname`, `fullname`, `description`, `type`, `applicable_grades`, `created`, `modified`)".
		" VALUES (NULL, '$data[0]', '$data[1]', '$data[2]', '$data[3]', '$data[4]', '$created', CURRENT_TIMESTAMP);";
		mysql_query($mysql);
	}
	
	
}
