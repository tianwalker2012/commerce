<?php

if (!defined('STATUSNET')) {
	exit(1);
}

/**
 * Table Definition for Schedule
 */

require_once INSTALLDIR.'/classes/Memcached_DataObject.php';

class Schedule extends Managed_DataObject
{
	###START_AUTOCODE
	/* the code below is auto generated do not remove the above tag */

	public $__table = 'Schedule';             // table name
	public $id;                      		// int primary_key not_null
	public $profile_id;						// int
	public $classgroup_id;                  // int
	public $type;							// tinyint
	public $period;		                   // int
	public $course_id;	                   // int
	public $start_date;                     // datetime
	public $end_date;						// datetime
	public $created;                         // datetime   not_null default_0000-00-00%2000%3A00%3A00
	public $modified;                         // timestamp   not_null default_0000-00-00%2000%3A00%3A00

	/* Static get */
	function staticGet($k,$v=NULL) { return Memcached_DataObject::staticGet('Schedule',$k,$v); }

	/* the code above is auto generated do not remove the tag below */
	###END_AUTOCODE

	const REPEATING		= 1;
	const CANCELLED		= 2;
	const ONETIME		= 3;
	
	public static function schemaDef()
	{
		return array(
				'fields' => array(
						'id' => array('type' => 'serial', 'not null' => true, 'description' => 'unique identifier'),
						'profile_id' => array('type' => 'int', 'not null' => false, 'description' => 'teacher who teaches this course'),
						'classgroup_id' => array('type' => 'int', 'not null' => true, 'description' => 'classgroup this course is created for'),
						'type' => array('type' => 'tinyint', 'length' => 4, 'not null' => true, 'description' => 'type of the schedule'),
						'period' => array('type' => 'int', 'not null' => true, 'description' => 'period this course is allocated with'),
						'course_id' => array('type' => 'int', 'not null' => true, 'description' => 'course id'),
						'start_date' => array('type' => 'datetime', 'not null' => false, 'description' => 'start date of the first course if a series is applied'),
						'end_date' => array('type' => 'datetime', 'not null' => false, 'description' => 'end date of the first course if a series is applied'),
						'created' => array('type' => 'datetime', 'not null' => true, 'description' => 'date the role was granted'),
						'modified' => array('type' => 'timestamp', 'not null' => true, 'description' => 'date the role was granted')
				),
				'primary key' => array('id'),
				'foreign keys' => array(
						'schedule_profile_id_fkey' => array('profile', array('profile_id' => 'id')),
						'schedule_classgroup_id_fkey' => array('user_group', array('classgroup_id' => 'id')),
						'schedule_course_id_fkey' =>  array('course', array('course_id' => 'id')),
						),
				'indexes' => array(
						'schedule_profile_id_idx' => array('profile_id'),
						'schedule_classgroup_id_idx' => array('classgroup_id'),
						'schedule_course_id_idx' => array('course_id'),
						'schedule_start_date_idx' => array('start_date'),
						),
		);
	}
	function pkeyGet($kv)
	{
		return Memcached_DataObject::pkeyGet('Schedule', $kv);
	}
	
	function insert($schedule)
	{
		common_link_db();
		$time=common_sql_now();
	 	$sql="INSERT INTO`statusnet`.`schedule` (
		`id` ,`profile_id` ,`classgroup_id` ,`type` ,`period` ,
		`course_id` ,
		`start_date` ,
		`end_date` ,
		`created` ,
		`modified`
		)
		VALUES (
		NULL ,'$schedule[profile_id]','$schedule[classgroup_id]','$schedule[type]','$schedule[period]','$schedule[course_id]',
		'$schedule[start_date]','$schedule[end_date]','$time','$time'
		)";
		$res=mysql_query($sql);
		if($res)
		{
			return true;
		}
		
	}
	
	function findall($id,$start,$end)
	{
		common_link_db();
		 $sql="select `id`,`start_date`,`course_id`,`period` from schedule where `classgroup_id`=".$id." And `type`=3 And ( `start_date` between '$start' and  '$end'  )";
		$result=mysql_query($sql);
	    $schedule=array();
	    $course=new Course;
        if(!empty($result))	  
        {
        	while($array=mysql_fetch_assoc($result))
        	{
        		$array['c_id']=$array['course_id'];
        		$array['start_date']=date('w',strtotime($array['start_date']));
        		$arr=$course->findone($array['course_id']);
        		$array['course_id']=$arr['fullname'];
        		$schedule[]=$array;
        	}
        }  
		$sql2="select `id`,`start_date`,`course_id`,`period` from schedule where `classgroup_id`=".$id." And `type`=1 ";
		$result2=mysql_query($sql2);
		$schedule2=array();
		while($array2=mysql_fetch_assoc($result2))
		{
			$l=$array2['start_date'];
			$array2['c_id']=$array2['course_id'];
			$arr=$course->findone($array2['course_id']);
			$array2['course_id']=$arr['fullname'];
			$array2['start_date']=date('w',strtotime($l));
			$schedule2[]=$array2;
		}
		$sqlsearch=array("sqla"=>$sql);
	    $schedule=array_merge($schedule,$sqlsearch);
	    $schedule=array_merge($schedule,$schedule2);
		return   $schedule;
	}
	
	function findOne($id)
	{
		common_link_db();
		$sql="select `period`,`profile_id`,`id`,`start_date`,`end_date` from schedule where `id`=".$id;
		$res=mysql_query($sql);
		if($oneSchedule=mysql_fetch_array($res)){
			return $oneSchedule;
		}
	}
	function deleteOne($id)
	{
		common_link_db();
		$sql="delete from schedule where id=".$id;
		$res=mysql_query($sql);
		if($res){
			return true;
		}
	}
	
	function checkExist($period,$class_id,$week)
	{
		common_link_db();                                                                                                                                    
		$sql="select `id` from schedule where `period`=".$period." and `classgroup_id`= ".$class_id." and  DATEPART ( weekday , start_date ) = ".$week;
		$res=mysql_query($sql);
		if($oneSchedule=mysql_fetch_array($res)){
			return true;
		}
		else
		{
			return false;
		}
	}
	function updateSchedule($schedule)
	{
		
		common_link_db();                                                                                                                                    
		$sql="UPDATE `statusnet`.`schedule` SET `profile_id` = '$schedule[profile_id]',
			`period` = '$schedule[period]',
			`start_date` = '$schedule[start_date]',
			`end_date` = '$schedule[end_date]'
			 WHERE `schedule`.`id` =".$schedule['s_id'];
		
		$res=mysql_query($sql);
		$sql2="UPDATE `statusnet`.`course` SET `description` = '$schedule[description]'
			 WHERE `course`.`id` =".$schedule['c_id'];
		$res2=mysql_query($sql2);
		if($res2&&$res)
		{
			return true;
		}
		else
		{
			return false;
		}

	}
	
	
}
