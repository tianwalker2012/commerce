<?php
/**
 * Table Definition for group_member
 */
require_once INSTALLDIR . '/classes/Memcached_DataObject.php';
class Cycle_member extends Managed_DataObject {
	// #START_AUTOCODE
	/* the code below is auto generated do not remove the above tag */
	public $__table = 'cycle_member'; // table name
	public $cycle_id; // int(4) primary_key not_null
	public $profile_id; // int(4) primary_key not_null
	public $created; // datetime() not_null
	public $modified; // timestamp() not_null default_CURRENT_TIMESTAMP
	
	/* Static get */
	function staticGet($k, $v = NULL) {
		return Memcached_DataObject::staticGet ( 'Cycle_member', $k, $v );
	}
	
	/* the code above is auto generated do not remove the tag below */
	// #END_AUTOCODE
	static function pivotGet($keyCol, $keyVals, $otherCols) {
		return Memcached_DataObject::pivotGet ( 'Cycle_member', $keyCol, $keyVals, $otherCols );
	}
	public static function schemaDef() {
		return array (
				'fields' => array (
						'cycle_id' => array (
								'type' => 'int',
								'not null' => true,
								'description' => '' 
						),
						'profile_id' => array (
								'type' => 'int',
								'not null' => true,
								'description' => 'foreign key to profile table' 
						),
						'created' => array (
								'type' => 'datetime',
								'not null' => true,
								'description' => 'date this record was created' 
						),
						'modified' => array (
								'type' => 'timestamp',
								'not null' => true,
								'description' => 'date this record was modified' 
						) 
				),
				'foreign keys' => array (
						'cycle_member_cycle_id_fkey' => array (
								'cycle',
								array (
										'cycle_id' => 'id' 
								) 
						),
						'cycle_member_profile_id_fkey' => array (
								'profile',
								array (
										'profile_id' => 'id' 
								) 
						) 
				),
				'indexes' => array (
						// @fixme probably we want a (profile_id, created) index
						// here?
						'cycle_member_cycle_id_idx' => array (
								'cycle_id' 
						),
						'cycle_member_profile_id_idx' => array (
								'profile_id' 
						) 
				) 
		);
	}
	function pkeyGet($kv) {
		return Memcached_DataObject::pkeyGet ( 'Cycle_member', $kv );
	}
	function getMember($groupid) {
		$cycle_m = new Cycle_member ();
		$cycle_m->cycle_id = $groupid;
		$cycle_m->find ();
		$persons = array ();
		 
			while ( $cycle_m->fetch () ) {
				array_push ( $persons, $cycle_m->profile_id );
			}
		 
		return $persons;
	}
	function getGroup($groupid) {
		$cycle = new Cycle ();
		$cycle->get ( 'id', $groupid );
		$profile_id = $this->getMember ( $groupid );
		return $group = array (
				'persons' => $profile_id,
				'group_id' => $cycle->id,
				'name' => $cycle->nickname,
				'own_id' => $cycle->owner_id,
				'created' => $cycle->created 
		);
	}
	function addMember($group_id, $persons) {
		if (! empty ( $group_id ) && ! empty ( $persons )) {
			$cycle=new Cycle();
			$cycle->get('id',$group_id);
			$members=$this->getMember($group_id);
			foreach ( $persons as $k => $v ) {
				if(!in_array($v, $members)){
				$cycle_member = new Cycle_member ();
				$cycle_member->cycle_id = $group_id;
				$cycle_member->profile_id = $v;
				$cycle_member->created = common_sql_now ();
				$cycle_id = $cycle_member->insert ();
				}
			}
			return true;
		} else {
			return false;
		}
	}
	function pushnotifiction($message,$cycle,$remove_id=array())
	{
        $member=$this->getMember($cycle->id);
        $member=array_values(array_diff($member, $remove_id));
        foreach ($member as $k=>$v){
		$pd = new Profile_detail ();
		$pd->profile_id = $v;
		$pd->field_name = "token";
		if ($pd->find ( true )) {
			$profile = new Profile ();
			$profile->get ( 'id', $v );
			common_simplepushgroupmessage ( $pd->field_value, $message, $cycle->id, $cycle->nickname, $cycle->created, $member, $cycle->owner_id );
		}
        }
		return true;
	}
	
	function getMyGroup($profile_id)
	{
		$group=array();
		$cycle_member=new Cycle_member();
		$cycle_member->profile_id=$profile_id;
		$cycle_member->find();
		while($cycle_member->fetch())
		{
			array_push($group, $cycle_member->cycle_id);
		}
		return $group;
	}
	
}
