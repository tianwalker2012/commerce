insert into location_namespace
    (id, description, created)
values
    (1, 'Geonames', now()),
    (2, 'Where on Earth', now());
