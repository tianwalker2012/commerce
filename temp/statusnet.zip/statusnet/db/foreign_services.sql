insert into foreign_service
    (id, name, description, created)
values
    ('1','Twitter', 'Twitter Micro-blogging service', now()),
    ('2','Facebook', 'Facebook', now()),
    ('3','FacebookConnect', 'Facebook Connect', now());
