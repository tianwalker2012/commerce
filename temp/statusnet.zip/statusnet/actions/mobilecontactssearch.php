<?php
/**
 * StatusNet - the distributed open-source microblogging tool
 * Copyright (C) 2008-2011, StatusNet, Inc.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @category Actions
 * @package  Actions
 * @author   Adrian Lang <mail@adrianlang.de>
 * @author   Brenda Wallace <shiny@cpan.org>
 * @author   Brion Vibber <brion@pobox.com>
 * @author   Craig Andrews <candrews@integralblue.com>
 * @author   Evan Prodromou <evan@status.net>
 * @author   Jeffery To <jeffery.to@gmail.com>
 * @author   Meitar Moscovitz <meitarm@gmail.com>
 * @author   Mike Cochrane <mikec@mikenz.geek.nz>
 * @author   Robin Millette <millette@status.net>
 * @author   Sarven Capadisli <csarven@status.net>
 * @author   Siebrand Mazeland <s.mazeland@xs4all.nl>
 * @author   Zach Copley <zach@status.net>
 * @copyright 2009 Free Software Foundation, Inc http://www.fsf.org
 * @license  GNU Affero General Public License http://www.gnu.org/licenses/
 * @link     http://status.net
 */


class MobileContactsSearchAction extends Action
{
		function handle($args)
		{
			$this->ContactsSearch();
		}
		function ContactsSearch()
		{  
            // $content=urlencode($this->trimmed('content'));
          $content=urldecode($this->trimmed('content'));
		  $return=array();
		  $qryfullname ="select id " .
   		  "from profile   " .
   		  "WHERE fullname  LIKE  '%".$content."%' " ;
		 $profile=new Profile();
		 $res=$profile->query($qryfullname);
		 $ids=array();
		
		 while($profile->fetch())
		 {
		 	 array_push($ids, $profile->id);
		 }
	 	   $qrymobile="select profile_id from profile_detail" .
		            " where field_name='phone' and field_value LIKE  '%".$content."%' ";
		 $p_d=new Profile_detail();
		 $p_d->query($qrymobile);  
		 while($p_d->fetch())
		 {
		 	 
		 	array_push($ids, $p_d->profile_id);
		 }
		
		 $ids=array_unique($ids);
		 
		
		 foreach ($ids as $k=>$V)
		 {
		 	$p1=new Profile();
		 	$p1->joinAdd(array('id','user:id'),'left');
		 	$p1->id=$V;
		 	$p1->find(true);
		 	
		 	$user=new User();
		 	$user->get('id',$V);
		  
		 	$avartar=new Avatar();
		 	$avartar->get('profile_id',$p1->id);
		 	$pdetail=$profile->getDetail($p1->id, 'phone');
		 	$return[]=array('profile_id'=>$p1->id,
		 			'fullname'=>$p1->fullname,
		 			'avatar_url'=>$avartar->url,
		 		    'email'=>$user->email,
		 			'mobilephone'=>$pdetail,);
		 }
		 
		    if($return)
		    {
		    	$returnResult=array('result'=>'success',
		    			'data'=>$return
		    	);
		    	echo json_encode($returnResult);
		    }
		    else
		    {
		    	$returnResult=array('result'=>'error');
		        echo json_encode($returnResult);
		    }
		    
		    
		 }
}
 
 
