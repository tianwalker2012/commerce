<?php
/**
 * StatusNet - the distributed open-source microblogging tool
 * Copyright (C) 2008-2011, StatusNet, Inc.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @category Actions
 * @package  Actions
 * @author   Adrian Lang <mail@adrianlang.de>
 * @author   Brenda Wallace <shiny@cpan.org>
 * @author   Brion Vibber <brion@pobox.com>
 * @author   Craig Andrews <candrews@integralblue.com>
 * @author   Evan Prodromou <evan@status.net>
 * @author   Jeffery To <jeffery.to@gmail.com>
 * @author   Meitar Moscovitz <meitarm@gmail.com>
 * @author   Mike Cochrane <mikec@mikenz.geek.nz>
 * @author   Robin Millette <millette@status.net>
 * @author   Sarven Capadisli <csarven@status.net>
 * @author   Siebrand Mazeland <s.mazeland@xs4all.nl>
 * @author   Zach Copley <zach@status.net>
 * @copyright 2009 Free Software Foundation, Inc http://www.fsf.org
 * @license  GNU Affero General Public License http://www.gnu.org/licenses/
 * @link     http://status.net
 */

class MobileLoginAction extends Action
{
		function handle($args)
			{
			  $username=$this->trimmed('username');
			  $password=$this->trimmed('password');
			  $this->MobileLogin($username, $password);
	    	}  
	    	
	    	
	    	function getgroupnotice()
	    	{   
	    		$profile=new Profile();
	    		$allgroup=$profile->getAllMyGroupId(1);
	    		
	    		foreach ($allgroup as $k=>$v)
	    		{
	    			$profile=new Profile();
	    			$notice=$profile->getMyGroupNotice($v,0,100);
	    			while($notice->fetch())
		    		 {
	    			 }
	    		}
	        }
	    	
	    	function MobileLogin($username,$password)
	    	{
	    		//$user = common_check_user($username, $password);
	    		$user=new User();
	    		$user->get('nickname',$username);
	    		if($user->id)
	    		{
	    			common_real_login(true);
	    			if ($this->boolean('rememberme')) {
	    				common_rememberme($user);
	    			}
	    			$url = common_get_returnto();
	    			$profile=new Profile();
	    			$profile->get('id',$user->id);
	    			$avater=new Avatar();
	    			$avater->get('profile_id',$user->id);
	    			$pdetail=$profile->getDetail($user->id, 'phone');
	    			$ptoken=$profile->getDetail($user->id, 'token');
	    			if(empty($ptoken))
	    			{
	    				$ptoken="";
	    			}
	    			 
	    			$user_Info=array('profile_id'=>$profile->id,
	    					'avatar'=>$avater->url,
	    					'fullname'=>$profile->fullname,
	    					'nickname'=>$profile->nickname,
	    					'session_token'=>(string)rand(1000, 2000),
	    					'token'=>$ptoken,
	    					'email'=>$user->email,
	    					'mobilephone'=>$pdetail,
	    			);
	    			$returnResult=array('result'=>'success','data'=>$user_Info);
	    			echo json_encode($returnResult);
	    		}
	    		else
	    		{
	    			$returnResult=array('result'=>'error');
	    			echo json_encode($returnResult);
	    		}
	    		
	    	}
	    	
	    	
	    	
	    	function getAllMyGroupMember($id)
	    	{
	    		$profile1=new Profile();
	    		$profile1->id=$id;
	    		$allGroup=$profile1->getGroups();
	    		$class_id=array();
	    		foreach ((array)($allGroup) as $k=>$v)
	    		{
	    			if(is_array($v)){
	    				foreach ($v as $k=>$b)
	    				{
	    					if(!common_valid_class($b->nickname))
	    					{
	    						$class_id[]=$b->id;
	    					}
	    				}
	    			}
	    		}
	    		$profile_information_class=array();
	    		if($class_id){
	    			$group=new User_group();
	    			foreach ($class_id as $k=>$v)
	    			{
	    				$group->get('id',$v);
	    				$profile = $group->getMembers();
	    				while($profile->fetch())
	    				{
	    					if($v!=$id)
	    					{
	    						array_push($profile_information_class,$profile->id);
	    					}
	    				}
	    			}
	    		}
	    		$profile_information_class=array_unique($profile_information_class);
	    		return $class_id;
	    	}
	    	
	    	
	    	
}
 
 
