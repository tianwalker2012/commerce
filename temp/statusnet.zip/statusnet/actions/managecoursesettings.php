<?php
 

if (!defined('STATUSNET') && !defined('LACONICA')) {
    exit(1);
}


/**
 * Change profile settings
 *
 * @category Settings
 * @package  StatusNet
 * @author   Evan Prodromou <evan@status.net>
 * @author   Zach Copley <zach@status.net>
 * @author   Sarven Capadisli <csarven@status.net>
 * @license  http://www.fsf.org/licensing/licenses/agpl-3.0.html GNU Affero General Public License version 3.0
 * @link     http://status.net/
 */
require_once INSTALLDIR.'/lib/managecourse.php';
class ManagecoursesettingsAction extends SettingsAction
{
    /**
     * Title of the page
     *
     * @return string Title of the page
     */
    function title()
    {
        // TRANS: Page title for profile settings.
        return _('课程管理页面');
    }
    function getInstructions()
    {
        // TRANS: Usage instructions for profile settings.
        return _('您可以管理课程信息');
    }
    /**
     * Content area of the page
     *
     * Shows a form for uploading an avatar.
     *
     * @return void
     */
    function showContent()
    {
    	$delete_course=$this->trimmed('delete');
    	if(!empty($delete_course))
    	{
    		$delete_course=$this->trimmed('remove');
    		if($delete_course)
    		{
    		foreach ($delete_course  as $k=>$v)
    		{
    			$course=new Course();
    			$course->delteCourse($v);
    		}
    		}
    		else {
    			 
    			echo "<script>alert('请选择要删除的学生');</script>";
    		}
    	}
    	
    	$insert=$this->trimmed('submit');
    	if(!empty($insert))
    	{
    		$nickname=$this->trimmed('editnickname');
    		$fullname=$this->trimmed('editfullname');
    		$description=$this->trimmed('editdescription');
    		$application_grade=$this->trimmed('application_grade');
    		$type=$this->trimmed('edittype');
    		$course=new Course();
    		$inCourse=array($nickname,$fullname,$description,$application_grade,$type);
    		$course->addcourse($inCourse);
    	}
    	$Managecourse=new Managecourse($this);
    	$Managecourse->show();
    }
    
    /**
     * Handle a post
     *
     * Validate input and save changes. Reload the form with a success
     * or error message.
     *
     * @return void
     */
    function handlePost()
    {}

    function nicknameExists($nickname)
    {
        $user = common_current_user();
        $other = User::staticGet('nickname', $nickname);
        if (!$other) {
            return false;
        } else {
            return $other->id != $user->id;
        }
    }

    function showAside() {
        $user = common_current_user();

        $this->elementStart('div', array('id' => 'aside_primary',
                                         'class' => 'aside'));

        $this->elementStart('div', array('id' => 'account_actions',
                                         'class' => 'section'));
        $this->elementStart('ul');
        if (Event::handle('StartProfileSettingsActions', array($this))) {
            if ($user->hasRight(Right::BACKUPACCOUNT)) {
                $this->elementStart('li');
                $this->element('a',
                               array('href' => common_local_url('backupaccount')),
                               // TRANS: Option in profile settings to create a backup of the account of the currently logged in user.
                               _('Backup account'));
                $this->elementEnd('li');
            }
            if ($user->hasRight(Right::DELETEACCOUNT)) {
                $this->elementStart('li');
                $this->element('a',
                               array('href' => common_local_url('deleteaccount')),
                               // TRANS: Option in profile settings to delete the account of the currently logged in user.
                               _('Delete account'));
                $this->elementEnd('li');
            }
            if ($user->hasRight(Right::RESTOREACCOUNT)) {
                $this->elementStart('li');
                $this->element('a',
                               array('href' => common_local_url('restoreaccount')),
                               // TRANS: Option in profile settings to restore the account of the currently logged in user from a backup.
                               _('Restore account'));
                $this->elementEnd('li');
            }
            Event::handle('EndProfileSettingsActions', array($this));
        }
        $this->elementEnd('ul');
        $this->elementEnd('div');
        $this->elementEnd('div');
    }
}
