<?php
/**
 * StatusNet - the distributed open-source microblogging tool
 * Copyright (C) 2008-2011, StatusNet, Inc.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @category Actions
 * @package  Actions
 * @author   Adrian Lang <mail@adrianlang.de>
 * @author   Brenda Wallace <shiny@cpan.org>
 * @author   Brion Vibber <brion@pobox.com>
 * @author   Craig Andrews <candrews@integralblue.com>
 * @author   Evan Prodromou <evan@status.net>
 * @author   Jeffery To <jeffery.to@gmail.com>
 * @author   Meitar Moscovitz <meitarm@gmail.com>
 * @author   Mike Cochrane <mikec@mikenz.geek.nz>
 * @author   Robin Millette <millette@status.net>
 * @author   Sarven Capadisli <csarven@status.net>
 * @author   Siebrand Mazeland <s.mazeland@xs4all.nl>
 * @author   Zach Copley <zach@status.net>
 * @copyright 2009 Free Software Foundation, Inc http://www.fsf.org
 * @license  GNU Affero General Public License http://www.gnu.org/licenses/
 * @link     http://status.net
 */


class MobileNoticeQueryByReaderAction extends Action
{
		function handle($args)
		{
			$this->NoticeQueryByReader();
		}
		function NoticeQueryByReader()
		{ 

			$id=$this->trimmed('id');
		    $start=floor($this->trimmed('start'));
			if($start<0||empty($start))
			{
				$start=0;
			}
		
			$limit=$this->trimmed('count');
			$subscribe=new Subscription();
			$subscribe->subscribed=$id;
			$sub=array();
			if($subscribe->find())
			{
				while($subscribe->fetch())
				{
					$sub[]=$subscribe->subscriber;
				}
			}
			$p_detail=new Profile_role();
			
			
			if($sub)
			{
				$profile_information=array();
				foreach ($sub as $k=>$v)
				{
					array_push($profile_information, $v);
				}
			}
			$profile=new Profile();
			$profile->id=$id;
			$a=$profile->getGroups();
			$class_id=array();
			foreach ((array)($a) as $k=>$v)
			{
				if(is_array($v)){
					foreach ($v as $k=>$b)
					{
						if(common_valid_class($b->nickname))
						{
							$class_id[]=$b->id;
						}
					}
				}
			}
			if($class_id){
				$profile_information_class=array();
				$group=new User_group();
				foreach ($class_id as $k=>$v)
				{
					 
					$group->get('id',$v);
					$profile = $group->getMembers();
					while($profile->fetch())
					{
						array_push($profile_information_class,$profile->id);
					}
				}
			}
			$p_tion=array();
			if(!empty($profile_information)){
			$profile_information_class=array_merge($profile_information,$profile_information_class);
			}
			$p_tion=array_unique($profile_information_class);
			$cur_user=array($id);
		    $str=implode(' , ',$p_tion);
			$profile_notice=array();
			$notice=new Notice();
			$notice->whereAdd();
			$notice->whereAdd("profile_id in ( ". $str. " )");
			$notice->whereAdd('reply_to is null');
			$notice->orderBy('created desc');
			$notice->limit($start,$limit);
			
			if($notice->find())
			{    
			 while($notice->fetch())
				 {
				 	 $file=new File(); 
			  		 $getnotice=$file->returnNoticeArray($notice);
			  		 $profile_notice[]=$getnotice;
				 }
		    }
			if($profile_notice)
			{
				$returnResult=array('result'=>'success',
						            'data'=>$profile_notice);
				echo json_encode($returnResult);
			}
			else
			{
				$returnResult=array('result'=>'error');
				echo json_encode($returnResult);
			}
				
		
}
}

 
 
