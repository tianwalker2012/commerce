<?php
 

if (!defined('STATUSNET') && !defined('LACONICA')) {
    exit(1);
}
 
class ImportcoursesettingsAction extends SettingsAction
{
   
    function title()
    {
        // TRANS: Page title for profile settings.
        return _('导入可科目信息');
    }

   
    function getInstructions()
    {
        return _('你可以导入您的科目信息');
    }
   
    function showContent()
    { 

    	$user = common_current_user();
    	$profile = $user->getProfile();
    	if (!$profile) {
    		common_log_db_error($user, 'SELECT', __FILE__);
    		// TRANS: Error message displayed when referring to a user without a profile.
    		$this->serverError(_('User has no profile.'));
    		return;
    	}
    	
    	$original = $profile->getOriginalAvatar();
    	
    	$this->elementStart('form', array('enctype' => 'multipart/form-data',
    			'method' => 'post',
    			'id' => 'form_settings_importclass',
    			'class' => 'form_settings',
    			'action' =>
    			common_local_url('managecoursesettings')));
    	$this->elementStart('ul', 'form_data');
    	$this->elementStart('li', array ('id' => 'settings_attach'));
    	$this->element('input', array('name' => 'MAX_FILE_SIZE',
    			'type' => 'hidden',
    			'id' => 'MAX_FILE_SIZE',
    			'value' => ImageFile::maxFileSizeInt()));
    	$this->element('input', array('name' => 'coursefile',
    			'type' => 'file',
    			'id' => 'avatarfile'));
    	$this->element('input', array('name' => 'importclasssettings',
    			'type' => 'hidden',
    			'value' => 'importclass'));
    	$this->elementEnd('li');
    	$this->elementEnd('ul');
    	 
    	$this->elementStart('ul', 'form_actions');
    	$this->elementStart('li');
    	// TRANS: Button on avatar upload page to upload an avatar.
    	$this->submit('upload', _m('BUTTON','Upload'));
    	$this->elementEnd('li');
    	$this->elementEnd('ul');
    	 
    	
    	$this->elementEnd('form');
    	$this->element('p',array(),'请导入如下图所示的CSV文件');
    	$this->element('div',array('class'=>'backgroundcourse'));
    }

     
    
    
    
    
    /**
     * Handle a post
     *
     * Validate input and save changes. Reload the form with a success
     * or error message.
     *
     * @return void
     */
    function handlePost()
    { }

    function nicknameExists($nickname)
    { }

    function showAside() {
        $user = common_current_user();

        $this->elementStart('div', array('id' => 'aside_primary',
                                         'class' => 'aside'));

        $this->elementStart('div', array('id' => 'account_actions',
                                         'class' => 'section'));
        $this->elementStart('ul');
        if (Event::handle('StartProfileSettingsActions', array($this))) {
            if ($user->hasRight(Right::BACKUPACCOUNT)) {
                $this->elementStart('li');
                $this->element('a',
                               array('href' => common_local_url('backupaccount')),
                               // TRANS: Option in profile settings to create a backup of the account of the currently logged in user.
                               _('Backup account'));
                $this->elementEnd('li');
            }
            if ($user->hasRight(Right::DELETEACCOUNT)) {
                $this->elementStart('li');
                $this->element('a',
                               array('href' => common_local_url('deleteaccount')),
                               // TRANS: Option in profile settings to delete the account of the currently logged in user.
                               _('Delete account'));
                $this->elementEnd('li');
            }
            if ($user->hasRight(Right::RESTOREACCOUNT)) {
                $this->elementStart('li');
                $this->element('a',
                               array('href' => common_local_url('restoreaccount')),
                               // TRANS: Option in profile settings to restore the account of the currently logged in user from a backup.
                               _('Restore account'));
                $this->elementEnd('li');
            }
            Event::handle('EndProfileSettingsActions', array($this));
        }
        $this->elementEnd('ul');
        $this->elementEnd('div');
        $this->elementEnd('div');
    }
}
