<?php
/**
 * StatusNet, the distributed open-source microblogging tool
 *
 * Change profile settings
 *
 * PHP version 5
 *
 * LICENCE: This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @category  Settings
 * @package   StatusNet
 * @author    Evan Prodromou <evan@status.net>
 * @author    Zach Copley <zach@status.net>
 * @author    Sarven Capadisli <csarven@status.net>
 * @copyright 2008-2009 StatusNet, Inc.
 * @license   http://www.fsf.org/licensing/licenses/agpl-3.0.html GNU Affero General Public License version 3.0
 * @link      http://status.net/
 */
require_once INSTALLDIR.'/lib/schedule.php';
if (!defined('STATUSNET') && !defined('LACONICA')) {
    exit(1);
}
/**
 * Change profile settings
 *
 * @category Settings
 * @package  StatusNet
 * @author   Evan Prodromou <evan@status.net>
 * @author   Zach Copley <zach@status.net>
 * @author   Sarven Capadisli <csarven@status.net>
 * @license  http://www.fsf.org/licensing/licenses/agpl-3.0.html GNU Affero General Public License version 3.0
 * @link     http://status.net/
 */
require_once INSTALLDIR.'/lib/schedule.php';
class ManageschedulesettingsAction extends SettingsAction
{	 
	 
	function showScripts()
	{
		parent::showScripts();
		$this->script('schedulestartmanage.js');
	}
	
    function title()
    {
        return _('课程表管理页面');
    }
     
    function getInstructions()
    {
        // TRANS: Usage instructions for profile settings.
        return _('课程表管理');
    }
    function showContent()
    { 
    	$hidden_value=$this->trimmed('saveschedule');
    	if(!empty($hidden_value))
    	{
    		$period=$this->trimmed('period');
    		$schedule=array();
    		$sch=new Schedule();
    		$schedule['type']=$this->trimmed('select_type');
    		if($schedule['type']==1){
    			$remove=$this->trimmed('remove');
    			$schedule['course_id']=$this->trimmed('select_course');
    			$schedule['classgroup_id']=$this->trimmed('select_class_name');
    			$schedule['profile_id']=$this->trimmed('select_teacher');
		        $schedule['start']=date_time($this->trimmed('fromtime'));
		        $week=date('w',strtotime($schedule['start']));
    		    $schedule['end_date']=date_time($this->trimmed('totime'));
    			foreach ($remove as $k=>$v){
    				if($v)
    				{
	    				if($period[--$v]!=0)
	    				{ 
	    					if(++$v>=$week)
	    					{
	    						$day=$v-$week;
	    					    $day=$day-1;
	    						$schedule['start_date']=date('Y/m/d',strtotime("$schedule[start] +$day day"));
		    					$schedule['period']=$period[--$v];
		    					//if($sch->checkExist($schedule['period'],$schedule['classgroup_id'],$week))
		    					//{
	    						$sch->insert($schedule);
		    					//}
	    					}
	    					else
	    					{
	    						$day=$week-$v;
	    						$schedule['start_date']=date('Y/m/d',strtotime("$schedule[start] +6 day"));
	    						$schedule['start_date']=date('Y/m/d',strtotime("$schedule[start_date] -$day day"));
	    						$schedule['period']=$period[--$v];
	    						//if($sch->checkExist($schedule['period'],$schedule['classgroup_id'],$week))
	    						//{
	    					    $sch->insert($schedule);
	    						//}
	    					}
	    				}
    			  }
    			}
    		}
    		else if($schedule['type']==3)
    		{
    			$schedule['classgroup_id']=$this->trimmed('select_class_name');
    			$schedule['course_id']=$this->trimmed('select_course');
    			$schedule['profile_id']=$this->trimmed('select_teacher');
    			$schedule['period']=$this->trimmed('weekend');
    			$date=date_time($this->trimmed('from'));
    			$schedule['start_date']=$date;
    			$schedule['end_date']=$date;
    			$sch->insert($schedule);
    		}
    			
    	}
    	
       $mangestulist=new managerSchedule($this,'user');
       $mangestulist->show();
    }

    
}
