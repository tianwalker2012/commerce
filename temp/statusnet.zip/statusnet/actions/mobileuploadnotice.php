<?php
/**
 * StatusNet - the distributed open-source microblogging tool
 * Copyright (C) 2008-2011, StatusNet, Inc.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @category Actions
 * @package  Actions
 * @author   Adrian Lang <mail@adrianlang.de>
 * @author   Brenda Wallace <shiny@cpan.org>
 * @author   Brion Vibber <brion@pobox.com>
 * @author   Craig Andrews <candrews@integralblue.com>
 * @author   Evan Prodromou <evan@status.net>
 * @author   Jeffery To <jeffery.to@gmail.com>
 * @author   Meitar Moscovitz <meitarm@gmail.com>
 * @author   Mike Cochrane <mikec@mikenz.geek.nz>
 * @author   Robin Millette <millette@status.net>
 * @author   Sarven Capadisli <csarven@status.net>
 * @author   Siebrand Mazeland <s.mazeland@xs4all.nl>
 * @author   Zach Copley <zach@status.net>
 * @copyright 2009 Free Software Foundation, Inc http://www.fsf.org
 * @license  GNU Affero General Public License http://www.gnu.org/licenses/
 * @link     http://status.net
 */

if (!defined('STATUSNET') && !defined('LACONICA')) {
    exit(1);
}
define('MAX_ORIGINAL', 480); 
class MobileUploadNoticeAction extends SettingsAction
{
    var $mode = null;
    var $imagefile = null;
    var $filename = null;

    function handle()
    {
    	if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $this->handlePost();
        }else{
    	  $this->showContent();
        }
      }
    
    
    /**
     * Title of the page
     *
     * @return string Title of the page
     */
    function title()
    {
        // TRANS: Title for avatar upload page.
        return _('Avatar');
    }

    function showLocalNav()
    {
    	
    }
    
    /**
     * Instructions for use
     *
     * @return instructions for use
     */
    function getInstructions()
    {
        // TRANS: Instruction for avatar upload page.
        // TRANS: %s is the maximum file size, for example "500b", "10kB" or "2MB".
        return sprintf(_('You can upload your personal avatar. The maximum file size is %s.'),
                       ImageFile::maxFileSize());
    }

    /**
     * Content area of the page
     *
     * Shows a form for uploading an avatar.
     *
     * @return void
     */

    function showContent()
    {
    	    $profile_id= $this->trimmed('notice');
    	    $profile=new Profile();
    	    $profile->get('id',$profile_id);
    	    $user=new User();
    	    $user->get('id',$profile_id);
            $this->showUploadForm($profile,$user);
    }

    function showUploadForm($profile,$user)
    {
    	
        if (!$profile) {
            common_log_db_error($user, 'SELECT', __FILE__);
            // TRANS: Error message displayed when referring to a user without a profile.
            $this->serverError(_('User has no profile.'));
            return;
        }

        $original = $profile->getOriginalAvatar();

        $this->elementStart('form', array('enctype' => 'multipart/form-data',
                                          'method' => 'post',
                                          'id' => 'form_settings_avatar',
                                          'class' => 'form_settings',
                                          'action' =>
                                          common_local_url('mobileuploadnotice',array('notice'=>$this->trimmed('notice')))));
        $this->elementStart('fieldset');
        // TRANS: Avatar upload page form legend.
        $this->element('legend', null, _('Avatar settings'));
        $this->hidden('token', common_session_token());

        if (Event::handle('StartAvatarFormData', array($this))) {
            $this->elementStart('ul', 'form_data');
            $avatar = $profile->getAvatar(AVATAR_PROFILE_SIZE);
            $this->elementStart('li', array ('id' => 'settings_attach'));
            $this->element('input', array('name' => 'MAX_FILE_SIZE',
                                          'type' => 'hidden',
                                          'id' => 'MAX_FILE_SIZE',
                                          'value' => ImageFile::maxFileSizeInt()));
            $this->element('input', array('name' => 'avatarfile',
                                          'type' => 'file',
                                          'id' => 'avatarfile'));
            $this->elementEnd('li');
            $this->elementEnd('ul');
            $this->elementStart('ul', 'form_actions');
            $this->elementStart('li');
             
                // TRANS: Button on avatar upload page to upload an avatar.
            $this->submit('upload', _m('BUTTON','Upload'));
            $this->elementEnd('li');
            $this->elementEnd('ul');
        }
        Event::handle('EndAvatarFormData', array($this));
        
        $this->elementEnd('fieldset');
        $this->elementEnd('form');
    }

    function showCropForm($profile,$user)
    { }

    /**
     * Handle a post
     *
     * We mux on the button name to figure out what the user actually wanted.
     *
     * @return void
     */
    function handlePost( )
    {
        // Workaround for PHP returning empty $_POST and $_FILES when POST
        // length > post_max_size in php.ini
    	$profile_id= $this->trimmed('notice');
    	$profile=new Profile();
    	$profile->get('id',$profile_id);
    	$user=new User();
    	$user->get('id',$profile_id);

        // CSRF protection

    	 
    	$this->uploadAvatar($profile,$user);

    }

    /**
     * Handle an image upload
     *
     * Does all the magic for handling an image upload, and crops the
     * image by default.
     *
     * @return void
     */
    function uploadAvatar($profile,$user)
    {
        try {
            $imagefile = ImageFile::fromUpload('avatarfile');
        } catch (Exception $e) {
            $this->showForm($e->getMessage());
            return;
        }
        if ($imagefile === null) {
            // TRANS: Validation error on avatar upload form when no file was uploaded.
            $this->showForm(_('No file uploaded.'));
            return;
        }

        $cur = $user;
        $type = $imagefile->preferredType();
        $filename = Avatar::filename($cur->id,
                                     image_type_to_extension($type),
                                     null,
                                     'tmp'.common_timestamp());

        $filepath = Avatar::path($filename);
        $imagefile->copyTo($filepath);

        $filedata = array('filename' => $filename,
                          'filepath' => $filepath,
                          'width' => $imagefile->width,
                          'height' => $imagefile->height,
                          'type' => $type);

        $_SESSION['FILEDATA'] = $filedata;

        $this->filedata = $filedata;

        $this->mode = 'crop';
      

        $filedata = $_SESSION['FILEDATA'];
        if (!$filedata) {
        	// TRANS: Server error displayed if an avatar upload went wrong somehow server side.
        	$this->serverError(_('Lost our file data.'));
        	return;
        }
        $file_d = ($filedata['width'] > $filedata['height'])
        ? $filedata['height'] : $filedata['width'];
        $dest_x = $this->arg('avatar_crop_x') ? $this->arg('avatar_crop_x'):0;
        $dest_y = $this->arg('avatar_crop_y') ? $this->arg('avatar_crop_y'):0;
        $dest_w = $this->arg('avatar_crop_w') ? $this->arg('avatar_crop_w'):$file_d;
        $dest_h = $this->arg('avatar_crop_h') ? $this->arg('avatar_crop_h'):$file_d;
        $size = min($dest_w, $dest_h, MAX_ORIGINAL);
        
        
        $imagefile = new ImageFile($user->id, $filedata['filepath']);
        $filename = $imagefile->resize($size, $dest_x, $dest_y, $dest_w, $dest_h);
        
        if ($profile->setOriginal($filename)) {
        	@unlink($filedata['filepath']);
        	unset($_SESSION['FILEDATA']);
        	// TRANS: Success message for having updated a user avatar.
        	//echo "123";
        	$profile_id= $this->trimmed('notice');
        	$avatar=new Avatar();
        	$avatar->height='96';
            $avatar->find(true);
            if($avatar->url)
            {
            	$user_info=array('url'=>$avatar->url);
            	$returnResult=array('result'=>'success','data'=>$user_info);
            	echo json_encode($returnResult);
            }
        	//$this->showForm(_('恭喜你头像更新成功了'), true);
        	common_broadcast_profile($profile);
        } else {
        	// TRANS: Error displayed on the avatar upload page if the avatar could not be updated for an unknown reason.
        	$returnResult=array('result'=>'error');
        	echo json_encode($returnResult);
        }
        
        
        
        
        // TRANS: Avatar upload form instruction after uploading a file.
      //  $this->showForm(_('你可以进行对头像的裁剪.'),
     //                   true);
    }

    /**
     * Get rid of the current avatar.
     *
     * @return void
     */
    function deleteAvatar()
    {
        $user = common_current_user();
        $profile = $user->getProfile();

        $avatar = $profile->getOriginalAvatar();
        if($avatar) $avatar->delete();
        $avatar = $profile->getAvatar(AVATAR_PROFILE_SIZE);
        if($avatar) $avatar->delete();
        $avatar = $profile->getAvatar(AVATAR_STREAM_SIZE);
        if($avatar) $avatar->delete();
        $avatar = $profile->getAvatar(AVATAR_MINI_SIZE);
        if($avatar) $avatar->delete();

        // TRANS: Success message for deleting a user avatar.
        $this->showForm(_('Avatar deleted.'), true);
    }

    /**
     * Add the jCrop stylesheet
     *
     * @return void
     */

    function showStylesheets()
    {
        parent::showStylesheets();
        $this->cssLink('css/jquery.Jcrop.css','base','screen, projection, tv');
    }

    /**
     * Add the jCrop scripts
     *
     * @return void
     */
    function showScripts()
    {
        parent::showScripts();

        if ($this->mode == 'crop') {
            $this->script('jcrop/jquery.Jcrop.min.js');
            $this->script('jcrop/jquery.Jcrop.go.js');
        }

        $this->autofocus('avatarfile');
    }
	}
 
