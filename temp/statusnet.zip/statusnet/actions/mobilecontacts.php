<?php
/**
 * StatusNet - the distributed open-source microblogging tool
 * Copyright (C) 2008-2011, StatusNet, Inc.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @category Actions
 * @package  Actions
 * @author   Adrian Lang <mail@adrianlang.de>
 * @author   Brenda Wallace <shiny@cpan.org>
 * @author   Brion Vibber <brion@pobox.com>
 * @author   Craig Andrews <candrews@integralblue.com>
 * @author   Evan Prodromou <evan@status.net>
 * @author   Jeffery To <jeffery.to@gmail.com>
 * @author   Meitar Moscovitz <meitarm@gmail.com>
 * @author   Mike Cochrane <mikec@mikenz.geek.nz>
 * @author   Robin Millette <millette@status.net>
 * @author   Sarven Capadisli <csarven@status.net>
 * @author   Siebrand Mazeland <s.mazeland@xs4all.nl>
 * @author   Zach Copley <zach@status.net>
 * @copyright 2009 Free Software Foundation, Inc http://www.fsf.org
 * @license  GNU Affero General Public License http://www.gnu.org/licenses/
 * @link     http://status.net
 */


class MobileContactsAction extends Action
{
		function handle($args)
		{
			$this->QueryFirend();
		}
		function QueryFirend()
		{  
			$id=$this->trimmed('id');
		    $subscribe=new Subscription();
		    $subscribe->subscriber=$id;
		    $sub=array();
		    $pids=array();
		    if($subscribe->find())
		    {
		    	while($subscribe->fetch())
		    	{
		    		$sub[]=$subscribe->subscribed;
		    	}
		    }
		  
		    $profile_information=array();
		    if($sub)
		    {
		    	foreach ($sub as $k=>$v)
		    	{
		    		if($id!=$v){
		    		$role="";
		    		$profile=new Profile();
		    		$profile->joinAdd(array('id','user:id'));
		    		$profile->id=$v;
		    		$profile->find(true);
		    		
		    		$avartar=new Avatar();
		    		$p_detail=new Profile_role();
		    		$role=$p_detail->getRole($v);
		    		$avartar->get('profile_id',$v);
		    	  
		    		$u=new User();
		    		$u->get('id',$v);
		    		 
		    		$pdetail=$profile->getDetail($id, 'phone');
		    		$profile_information[]=array('profile_id'=>$v,
						    				   'fullname'=>$profile->fullname,
						    				   'avatar'=>$avartar->url,
						    				   'type'=>'friend',
						    				   'roleprofile'=>$role,
		    				                   'email'=>$u->email,
		    								   'mobilephone'=>$pdetail,
		    				    );
		    		}
		    	}
		    } 
		    $profile1=new Profile();
		    $profile1->id=$id;
		    $allGroup=$profile1->getGroups();
		    $class_id=array();
		    foreach ((array)($allGroup) as $k=>$v)
		    {
		    	if(is_array($v)){
		    	foreach ($v as $k=>$b)
			    	{
			    		if(common_valid_class($b->nickname))
			    		{
			                 $class_id[]=$b->id;
			    		}
			    	}
		    	}
		    }
		   $profile_information_class=array();
           if($class_id){
           	$group=new User_group();
             foreach ($class_id as $k=>$v)
             {
             	$group->get('id',$v);
             	$profile = $group->getMembers();
             	
             	while($profile->fetch())
             	{
             		if(!in_array($profile->id,$pids)){
             	  	array_push($pids,$profile->id);
	                  if($id!=$profile->id){
	                  	$user=new User();
	                  	$user->get('id',$profile->id);
	                  	$p_detail=new Profile_role();
	                  	$avartar=new Avatar();
	                  	$avartar->get('profile_id',$profile->id);
	                  	$pdetail=$profile->getDetail($id, 'phone');
	             		$role=$p_detail->getRole($profile->id);
	             	 
	              		  $profile_information_class[]=array('profile_id'=>$profile->id,
							             				   'fullname'=>$profile->fullname,
							             				   'avatar'=>$avartar->url,
							             				   'group_id'=>$id,
							             				   'type'=>'group',
							             				   'roleprofile'=>$role,
										                   'email'=>$user->email,
										             	   'mobilephone'=>$pdetail,
	             				);
	             		 }
	             	
             	  }
             	}
             }		    
		    }
		    
		    $profile_information=array_merge($profile_information,$profile_information_class);
		    
			if($profile_information)
			{
				$returnResult=array('result'=>'success',
						            'data'=>$profile_information
						                );
				echo json_encode($returnResult);
			}
			else
			{
				$returnResult=array('result'=>'error');
				echo json_encode($returnResult);
			}
		}
}
 
		function assoc_unique($arr)
             { 
             	
             	$temp=array();
	             foreach ($arr as $k=>$v){
		               foreach ($temp as $kk=>$vv){
			               	if($vv['profile_id']==$v['profile_id']){
			               		break;
			               	} 
		               }	
	             }  
	                       
             }
