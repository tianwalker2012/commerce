<?php
 

if (!defined('STATUSNET') && !defined('LACONICA')) {
    exit(1);
}
require_once INSTALLDIR.'/lib/managecourse.php';
class NewcoursesettingsAction extends SettingsAction
{
   
    function title()
    {
        // TRANS: Page title for profile settings.
        return _('添加一个新的科目');
    }
    function getInstructions()
    {
        // TRANS: Usage instructions for profile settings.
        return _('添加科目');
    }
    function showContent()
    { 
    	$mangestulist=new Managecourse($this,'user');
        $mangestulist->showContentNew();
    	
    }
    function nicknameExists($nickname)
    {
        $user = common_current_user();
        $other = User::staticGet('nickname', $nickname);
        if (!$other) {
            return false;
        } else {
            return $other->id != $user->id;
        }
    }

    function showAside() { }
}
