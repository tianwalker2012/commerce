<?php

if (! defined ( 'STATUSNET' ) && ! defined ( 'LACONICA' )) {
	exit ( 1 );
}
 
require_once INSTALLDIR . '/lib/action.php';
class MobileMessageGroupQueryAction extends Action {
	function handle($args) {
		$this->MobileMessageCycleQuery ();
	}
	function MobileMessageCycleQuery() {
		   $cycleid = $this->trimmed ( 'group_id' );
		 
		  $limit = $this->trimmed ( 'limit' );
		$start = $this->trimmed ( 'start' );
		if ($start <= 0) {
			$start = 0;
		}       
		$cycle=new Cycle();
		$cycle->get('id',$cycleid);
		$message = new Message ();
		$message->cycleid = $cycleid;
		$message->orderBy ( 'created desc' );
		$message->limit($start,$limit);
		if ($message->find ()) {
			$return = array ();
			while ( $message->fetch () ) {
				$return [] = array (
						'mesid' => $message->id,
						'from' => $message->from_profile,
						'cycleid' => $message->cycleid,
						'content' => $message->content,
						'source' => $message->source,
						'created' => $message->created 
				);
			}
		}
		if (!empty($cycle->created)) {
			if (! empty ( $return )) {
				$returnResult = array (
						'result' => 'success',
						'data' => $return 
				);
			} else {
				$returnResult = array (
						'result' => 'success'
				);
			}
			echo json_encode ( $returnResult );
		} else {
			$returnResult = array (
					'result' => 'error' 
			);
			echo json_encode ( $returnResult );
		}
	}
}
 
 
