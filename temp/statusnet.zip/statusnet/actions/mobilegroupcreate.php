<?php
/**
 * StatusNet - the distributed open-source microblogging tool
 * Copyright (C) 2008-2011, StatusNet, Inc.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @category Actions
 * @package  Actions
 * @author   Adrian Lang <mail@adrianlang.de>
 * @author   Brenda Wallace <shiny@cpan.org>
 * @author   Brion Vibber <brion@pobox.com>
 * @author   Craig Andrews <candrews@integralblue.com>
 * @author   Evan Prodromou <evan@status.net>
 * @author   Jeffery To <jeffery.to@gmail.com>
 * @author   Meitar Moscovitz <meitarm@gmail.com>
 * @author   Mike Cochrane <mikec@mikenz.geek.nz>
 * @author   Robin Millette <millette@status.net>
 * @author   Sarven Capadisli <csarven@status.net>
 * @author   Siebrand Mazeland <s.mazeland@xs4all.nl>
 * @author   Zach Copley <zach@status.net>mobileaddgroup
 * @copyright 2009 Free Software Foundation, Inc http://www.fsf.org
 * @license  GNU Affero General Public License http://www.gnu.org/licenses/
 * @link     http://status.net
 */


class MobileGroupCreateAction extends Action
{
		function handle($args)
		{
			$this->MobileCycleCreate();
		}
		function MobileCycleCreate()
		{ 
		 	$cycle_id=$this->trimmed('persons');
		  //	$cycle_id=array(1,3,4,5,7,10);
			$name=$this->trimmed('name');
			//$name="testcycle";
	        $owner_id=$this->trimmed('owner_id');
	       // $owner_id="1";
	        $profile=new Profile();
	        $profile->get('id',$owner_id);
			$cycle=new Cycle();
		  	$cycle->nickname=$name;
		    $cycle->owner_id=$owner_id;
			$cycle->created=common_sql_now();
	     	$cycle->insert();
		    $cycle->get('created',$cycle->created);
		    $message="";
		    foreach ($cycle_id as $k=>$v)
		    {
		    	$profile=new Profile();
		    	$profile->get('id',$v);
		    	$message.=$profile->getBestName()."、";
		    }
		     $message=$profile->getBestName()."创建了一个新的群组,并且你被加入了".$cycle->nickname."群组";
		     $cycle_member=new Cycle_member();
		    $result=$cycle_member->addMember($cycle->id, $cycle_id);
		    $member=$cycle_member->getMember($cycle->id);
		    $cycle_m=new Cycle_member();
			 $result=$cycle_m->pushnotifiction($message, $cycle);
			$queruy_result=$cycle->getOneInf($cycle->id);
			if($queruy_result)
			{
				$returnResult=array('result'=>'success','data'=>$queruy_result);
				echo json_encode($returnResult);
			}
			else
			{
				$returnResult=array('result'=>'error');
				echo json_encode($returnResult);
			}
			
			
		}	
		
}
