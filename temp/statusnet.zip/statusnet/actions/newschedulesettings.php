<?php
 
require_once INSTALLDIR.'/lib/schedule.php';
if (!defined('STATUSNET') && !defined('LACONICA')) {
    exit(1);
}
 
require_once INSTALLDIR.'/lib/schedule.php';
class NewschedulesettingsAction extends SettingsAction
{
     
    function title()
    {
        // TRANS: Page title for profile settings.
        return _('添加课程表');
    }
    /**
     * Instructions for use
     *
     * @return instructions for use
     */
    function getInstructions()
    {
        return _('添加课程表');
    }
    function showContent()
    { 
       $mangestulist=new managerSchedule($this,'user');
       $mangestulist->showNewSchedule();
    }

    
}
