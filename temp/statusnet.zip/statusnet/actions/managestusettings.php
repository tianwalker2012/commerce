<?php
 

if (!defined('STATUSNET') && !defined('LACONICA')) {
    exit(1);
}

 
require_once INSTALLDIR.'/lib/mangestulist.php';
class ManagestusettingsAction extends SettingsAction
{
    
    function title()
    {
        // TRANS: Page title for profile settings.
        return _('学生管理页面');
    }
 
    function getInstructions()
    {
        // TRANS: Usage instructions for profile settings.
        return _('您可以管理您的学生信息');
    }
    /**
     * Content area of the page
     *
     * Shows a form for uploading an avatar.
     *
     * @return void
     */
    function showContent()
    { 
    	$insert_value=$this->trimmed('insert_stu');
    	if(!empty($insert_value))
    	{
    		$nicakname=$this->trimmed('insert_stunickname');
    		$fullname=$this->trimmed('insert_stufullname');
    		$kidsex=$this->trimmed('insert_kidsex');
    		$kidbirthday=$this->trimmed('insert_kidbirthday');
    		$kidname=$this->trimmed('insert_kidsname');
    		$role=$this->trimmed('insert_sturole');
    		$mobilePhone=$this->trimmed('insert_stuphone');
    		$email=$this->trimmed('insert_email');
    		$classnickname=$this->trimmed('insert_default_class');
    		$arr=array('1'=>$nicakname,'2'=>$fullname,'3'=>$email,'4'=>$kidname,
    				'5'=>$kidsex,    '6'=>$kidbirthday, '7'=>$role,'8'=>$mobilePhone,
    				'9'=>$classnickname,
    		);
    		$user=new User();
    		$user->registerFromFile($arr);
    	}
    	$submit_remove_profile=$this->trimmed('submit_remove_profile');
    	
    	if(!empty($submit_remove_profile))
    	{
    		$submit_remove_profile=$this->trimmed('remove');
    		if($submit_remove_profile)
    		{
	    		foreach($submit_remove_profile as $k=>$v)
	    		{
	    		$user=new User();
	    		$user->remov_user($v);
	    		}
    		}
    		else {
    			
    			echo "<script>alert('请选择要删除的学生');</script>";
    		}
    	}
    	$view_remove_id=$this->trimmed('view_remove_id');
    	if(!empty($view_remove_id))
    	{
    		$user=new User();
    		$user->remov_user($view_remove_id);
    	}
    	
    	
    	
    	$manger=new MangeStuList($this,'class');
    	$manger->show();
    	
    }
    
    /**
     * Handle a post
     *
     * Validate input and save changes. Reload the form with a success
     * or error message.
     *
     * @return void
     */
    function handlePost()
    { }

    function nicknameExists($nickname)
    {
        $user = common_current_user();
        $other = User::staticGet('nickname', $nickname);
        if (!$other) {
            return false;
        } else {
            return $other->id != $user->id;
        }
    }

    function showAside() { }
}
