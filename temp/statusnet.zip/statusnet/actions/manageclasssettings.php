<?php

if (!defined('STATUSNET') && !defined('LACONICA')) {
    exit(1);
}


/**
 * Change profile settings
 *
 * @category Settings
 * @package  StatusNet
 * @author   Evan Prodromou <evan@status.net>
 * @author   Zach Copley <zach@status.net>
 * @author   Sarven Capadisli <csarven@status.net>
 * @license  http://www.fsf.org/licensing/licenses/agpl-3.0.html GNU Affero General Public License version 3.0
 * @link     http://status.net/
 */
require_once INSTALLDIR.'/lib/mangelist.php';
class ManageclasssettingsAction extends SettingsAction
{
    /**
     * Title of the page
     *
     * @return string Title of the page
     */
    function title()
    {
        // TRANS: Page title for profile settings.
        return _('班级管理');
    }

    /**
     * Instructions for use
     *
     * @return instructions for use
     */
    function getInstructions()
    {
        // TRANS: Usage instructions for profile settings.
        return _('您可以管理您的班级信息');
    }
    /**
     * Content area of the page
     *
     * Shows a form for uploading an avatar.
     *
     * @return void
     */
    function showContent()
    { 
    	
    	$insert=$this->trimmed('insert');
    	if(!empty($insert))
    	{
    		$admin = $this->trimmed('insrtadmin');
    		$name = $this->trimmed('insertnickname');
    		$fullname = $this->trimmed('insertfullname');
    		$insrtdescription = $this->trimmed('insrtdescription');
    		$arr=array('1'=>$name,'2'=>$admin,'3'=>$fullname,'4'=>$insrtdescription);
    		$user_group=new User_group();
    		$user_group->addClassGroupFromFile($arr);
    		 
    	}
    	$submitremove=$this->trimmed('submitremove');
    	if(!empty($submitremove))
    	{
    		$arr=$this->trimmed('remove');
    		if($arr)
    		{
    		foreach ($arr as $k=>$v)
    		{
    			$user_group=new User_group();
    			$user_group->remove_class($v);
    		}
    		}
    		else {
    			 
    			echo "<script>alert('请选择要删除的学生');</script>";
    		}
    	}
    	$view_remove_id=$this->trimmed('view_remove_id');
    	if(!empty($view_remove_id))
    	{
    		$user_group=new User_group();
    		$user_group->remove_class($view_remove_id);
    	}
    	$manger=new MangeList($this,'class');
    	$manger->show();
    	
    	//$cnt=$manger->show();
    	//$this->page=$this->trimmed('page');
    /*	  $this->pagination(
    			$this->page > 1, $cnt > NOTICES_PER_PAGE,
    			$this->page, 'manageclasssettings'
    	); */
    }
    
    /**
     * Handle a post
     *
     * Validate input and save changes. Reload the form with a success
     * or error message.
     *
     * @return void
     */
    function handlePost()
    { }

    function nicknameExists($nickname)
    {
        $user = common_current_user();
        $other = User::staticGet('nickname', $nickname);
        if (!$other) {
            return false;
        } else {
            return $other->id != $user->id;
        }
    }

    
}
