<?php
/**
 * StatusNet - the distributed open-source microblogging tool
 * Copyright (C) 2008-2011, StatusNet, Inc.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @category Actions
 * @package  Actions
 * @author   Adrian Lang <mail@adrianlang.de>
 * @author   Brenda Wallace <shiny@cpan.org>
 * @author   Brion Vibber <brion@pobox.com>
 * @author   Craig Andrews <candrews@integralblue.com>
 * @author   Evan Prodromou <evan@status.net>
 * @author   Jeffery To <jeffery.to@gmail.com>
 * @author   Meitar Moscovitz <meitarm@gmail.com>
 * @author   Mike Cochrane <mikec@mikenz.geek.nz>
 * @author   Robin Millette <millette@status.net>
 * @author   Sarven Capadisli <csarven@status.net>
 * @author   Siebrand Mazeland <s.mazeland@xs4all.nl>
 * @author   Zach Copley <zach@status.net>
 * @copyright 2009 Free Software Foundation, Inc http://www.fsf.org
 * @license  GNU Affero General Public License http://www.gnu.org/licenses/
 * @link     http://status.net
 */


class MobileNoticeQueryAction extends Action
{
		function handle($args)
		{
			$this->QueryOneNotice();
		}
		function QueryOneNotice()
		{
	 		$id=$this->trimmed('id');
			$notice=new Notice();
			$notice->get('id',$id);
			
			$file_to_post=new File_to_post();
		    $file_to_post->post_id=$id;
		    $file=array();
			if($file_to_post->find())
			{ 
			while($file_to_post->fetch())
			{
				$file[]=$file_to_post->file_id;
			}
			}
			$attach=array();
			foreach ($file as $k=>$v)
			{
				$file=new File();
				$file->get('id',$v);
				if($file) 
				{
				$attach[]=array('type'=>$file->mimetype,
		  					 	'url'=>$file->url);
				}
			}
			if($notice)
			{
				$detail[]=array('id'=>$notice->id,
								'profile_id'=>$notice->profile_id,
								'created'=>$notice->created,
								'reply_to'=>$notice->reply_to,
								'content'=>$notice->content,
						        'scope'=>$notice->scope,
								'attachments'=>$attach
            		              	) ;
				$returnResult=array('result'=>'success',
						            'data'=>$detail
						                );
				echo json_encode($returnResult);
			}
			else
			{
				$returnResult=array('result'=>'error');
				echo json_encode($returnResult);
			}
		}
}
 
 
