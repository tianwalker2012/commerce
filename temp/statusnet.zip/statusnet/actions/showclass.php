 <?php
/**
 * StatusNet, the distributed open-source microblogging tool
 *
 * Group main page
 *
 * PHP version 5
 *
 * LICENCE: This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @category  Group
 * @package   StatusNet
 * @author    Evan Prodromou <evan@status.net>
 * @author    Sarven Capadisli <csarven@status.net>
 * @copyright 2008-2011 StatusNet, Inc.
 * @license   http://www.fsf.org/licensing/licenses/agpl-3.0.html GNU Affero General Public License version 3.0
 * @link      http://status.net/
 */

if (!defined('STATUSNET') && !defined('LACONICA')) {
    exit(1);
}
 
require_once INSTALLDIR.'/lib/noticelist.php';
require_once INSTALLDIR.'/lib/feedlist.php';
require_once INSTALLDIR.'/lib/threadingnoticenotifystream.php';
require_once INSTALLDIR.'/lib/threadingnoticehomeworkstream.php';

/**
 * Group main page
 *
 * @category Group
 * @package  StatusNet
 * @author   Evan Prodromou <evan@status.net>
 * @license  http://www.fsf.org/licensing/licenses/agpl-3.0.html GNU Affero General Public License version 3.0
 * @link     http://status.net/
 */
class ShowclassAction extends GroupAction
{
    /** page we're viewing. */
    var $page = null;
    var $userProfile = null;
    var $notice = null;
    var $homework_notice = null;
    var $notify_notice = null;
     
    /**
     * Is this page read-only?
     *
     * @return boolean true
     */
    function isReadOnly($args)
    {
        return true;
        
    }

    /**
     * Title of the page
     *
     * @return string page title, with page number
     */
    function title()
    {
        $base = $this->group->getFancyName();

        if ($this->page == 1) {
            // TRANS: Page title for first group page. %s is a group name.
            return sprintf(_('%s group'), $base);
        } else {
            // TRANS: Page title for any but first group page.
            // TRANS: %1$s is a group name, $2$s is a page number.
            return sprintf(_('%1$s group, page %2$d'),
                           $base,
                           $this->page);
        }
    }

    /**
     * Prepare the action
     *
     * Reads and validates arguments and instantiates the attributes.
     *
     * @param array $args $_REQUEST args
     *
     * @return boolean success flag
     */
    function prepare($args)
    {
    	
        parent::prepare($args);
        $this->page = ($this->arg('page')) ? ($this->arg('page')+0) : 1;
       
        $this->userProfile = Profile::current();

        $user = common_current_user();
        if (!empty($user) && $user->streamModeOnly()) {
            $stream = new GroupNoticeStream($this->group, $this->userProfile);
        } else {
            $stream = new ThreadingNoticeSendMsgStream($this->group, $this->userProfile);
            $stream_home = new ThreadingNoticeHomeworkStream($this->group, $this->userProfile);
            $stream_notify = new ThreadingNoticeNotifyStream($this->group, $this->userProfile);
        }

        $this->notice = $stream->getNotices(($this->page-1)*NOTICES_PER_PAGE,
                                            NOTICES_PER_PAGE + 1);
        $this->homework_notice = $stream_home->getNotices(($this->page-1)*NOTICES_PER_PAGE,
                                            NOTICES_PER_PAGE + 1);
        $this->notify_notice = $stream_notify->getNotices(($this->page-1)*NOTICES_PER_PAGE,
                                            NOTICES_PER_PAGE + 1);
     
        common_log(LOG_INFO, $this->selfUrl());
        common_set_returnto($this->selfUrl());
        
        // add some comments
        
        return true;
    }

    /**
     * Handle the request
     *
     * Shows a profile for the group, some controls, and a list of
     * group notices.
     *
     * @return void
     */
    function handle($args)
    {
    	$clsgrp=common_current_classgroup();
    	if(common_switch_class($clsgrp)){
        	$this->showPage();
    	}
    }
        
    function showScripts()
    {
    	parent::showScripts();
		$this->script('markup.js');
		$this->script('subscription.js');
    	   
    }
    
    
	function showTab()
	{ 
		
	}
	
	function showProfileBlock()
	{
		 Action::showProfileBlock();
	}
    /**
     * Show the page content
     *
     * Shows a group profile and a list of group notices
     */
    function showContent()
    {
		$this->elementStart('div', array('id' => 'tabs'));
		
		$this->elementStart('ul');
	
		$this->elementStart('li',array(	));
		$this->elementStart('a',array('class'=>'tabchange','id'=>'tab2','href'=>'#tabs-1'));
		$this->raw(_('发言'));
		$this->elementEnd('a');
		$this->elementEnd('li');
		
	 	$this->elementStart('li',array());
		$this->elementStart('a',array('class'=>'tabchange','href'=>'#tabs-2'));
		$this->raw(_('作 业'));
		$this->elementEnd('a');
		$this->elementEnd('li');
	
		$this->elementStart('li',array());
		$this->elementStart('a',array('class'=>'tabchange','href'=>'#tabs-3'));
		$this->raw(_('通知'));
		$this->elementEnd('a');
		$this->elementEnd('li');

		$this->elementStart('li',array());
		$this->elementStart('a',array('class'=>'tabchange','href'=>'#tabs-4'));
		$this->raw(_('照片墙'));
		$this->elementEnd('a');
		$this->elementEnd('li');  
		 
		$this->elementEnd('ul');	// ul
		
		$this->elementStart('div',array('id'=>'tabs-1'));
	 	$this->showGroupNotices();
		$this->elementEnd('div');
		 
	 	$this->element("type",array('type'=>'hidden','value'=>''));
		$this->elementStart('div',array('id'=>'tabs-2'));
		 $this->showGroupHomeworkNotices();
		$this->elementEnd('div');
		
		$this->elementStart('div',array('id'=>'tabs-3'));
		 $this->showGroupNotifyNotices();		 
		$this->elementEnd('div');

		     
		$this->elementStart('div',array('id'=>'tabs-4'));
		 $this->showPics();
		$this->elementEnd('div'); 
			
		$this->elementEnd('div');	// tabs
    }
    
    function showPageTitle()
    {
    	$this->element("h1",array(),"班级信息墙");
    }
     
    function showNoticeForm()
    {
    	$group = new user_group();
    	$group->get('nickname',common_current_classgroup());
    	$_SESSION['class_id'] = $group->id;
    	$_SESSION['class_fullname'] = $group->getBestName();
    	
    	// TRANS: Tab on the notice form.
    	$tabs = array('status' => _m('TAB','Status'));
    
    	$this->elementStart('div', 'input_forms');
    	$current_user = common_current_user();
    	if (Event::handle('StartShowEntryForms', array(&$tabs))) {
    		 
    		$this->elementStart('ul', array('class' => 'nav',
    				'id' => 'input_form_nav'));
    
    		foreach ($tabs as $tag => $title) {
    			$attrs = array('id' => 'input_form_nav_'.$tag,
    					'class' => 'input_form_nav_tab');
    
    			if ($tag == 'status') {
    				// We're actually showing the placeholder form,
    				// but we special-case the 'Status' tab as if
    				// it were a small version of it.
    				$attrs['class'] .= ' current';
    			}
    			$this->elementStart('li', $attrs);
    
    			$this->element('a',
    					array('href' => 'javascript:SN.U.switchInputFormTab("'.$tag.'")'),
    					$title);
    			$this->elementEnd('li');
    		}
    		$this->elementEnd('ul');
    		$attrs = array('class' => 'input_form current',
    				'id' => 'input_form_placeholder');
    		$this->elementStart('div', $attrs);
    		$form = new NoticePlaceholderForm($this);
    		$form->show();
    		$this->elementEnd('div');
    
    		foreach ($tabs as $tag => $title) {
    			$attrs = array('class' => 'input_form',
    					'id' => 'input_form_'.$tag);
    
    			$this->elementStart('div', $attrs);
    			$form = null;
    
    			if (Event::handle('StartMakeEntryForm', array($tag, $this, &$form))) {
    				if ($tag == 'status') {
    				 	$options = $this->noticeFormOptions();
    					$form = new NoticeclassForm($this, $options);
    				}
    				Event::handle('EndMakeEntryForm', array($tag, $this, $form));
    			}
    
    			if (!empty($form)) {
    				$form->show();
    			}
                  
    			$this->elementEnd('div');
    			
    		}
    		
    	}
    	
    	$this->elementEnd('div');
    	// $this->showHighLight();
    
    }  
    
    function showHighLight()
    {
    	$this->elementStart('div',array('id'=>'highlight','class'=>'ui-state-highlight ui-corner-all'));
    	$this->elementStart("p");
    	$this->elementStart("span");
    	$this->element('strong','','Hey!');
    	$this->raw(" Sample ui-state-highlight style.通知栏");
    	$this->elementEnd("span");   
    	$this->elementEnd("p");   
    	$this->elementEnd('div');
    }
    
    /**
     * Show the group notices
     *
     * @return void
     */
    function showGroupNotices()
    {
        if (Event::handle('StartShowAllContent', array($this))) {

            $profile = null;
 
            $current_user = common_current_user();
            if (!empty($current_user)) {
                $profile = $current_user->getProfile();
            }
            
           
            if (!empty($current_user) && $current_user->streamModeOnly()) {
                $nl = new NoticeList($this->notice, $this);
            } else {
                $nl = new ThreadedNoticeList($this->notice, $this, $profile);
            }
          
            $cnt = $nl->show();

            if (0 == $cnt) {
                $this->showEmptyListMessage();
            }

            
            
            
            $this->pagination(
                $this->page > 1, 
            	$cnt > NOTICES_PER_PAGE,
                $this->page, 
            	'showclass', array('nickname' =>$this->group->nickname,'id'=>1)
            );

            Event::handle('EndShowAllContent', array($this));
        }
    }
    function showGroupHomeworkNotices()
    {
            $profile = null;
 
            $current_user = common_current_user();
            if (!empty($current_user)) {
                $profile = $current_user->getProfile();
            }
            
           
            if (!empty($current_user) && $current_user->streamModeOnly()) {
                $nl = new NoticeList($this->homework_notice, $this);
            } else {
                $nl = new ThreadedNoticeList($this->homework_notice, $this, $profile);
            }
          
            $cnt = $nl->show();

            if (0 == $cnt) {
                $this->showEmptyListMessage();
            }

            $this->pagination(
                $this->page > 1, 
            	$cnt > NOTICES_PER_PAGE,
                $this->page, 
            	'showclass', array('nickname' =>$this->group->nickname,'id'=>1)
            );
            
    }
    function showGroupNotifyNotices()
    {

            $profile = null;
 
            $current_user = common_current_user();
            if (!empty($current_user)) {
                $profile = $current_user->getProfile();
            }
           
            if (!empty($current_user) && $current_user->streamModeOnly()) {
                $nl = new NoticeList($this->notify_notice, $this);
            } else {
                $nl = new ThreadedNoticeList($this->notify_notice, $this, $profile);
            }
          
            $cnt = $nl->show();

            if (0 == $cnt) {
                $this->showEmptyListMessage();
            }

            $this->pagination(
                $this->page > 1, 
            	$cnt > NOTICES_PER_PAGE,
                $this->page, 
            	'showclass', array('nickname' =>$this->group->nickname,'id'=>1)
            );
    }
    
/**
     * Show the group notices
     *
     * @return void
     */
    function showGroupAdminNotices()
    {
        $user = common_current_user();

        if (!empty($user) && $user->streamModeOnly()) {
            $nl = new NoticeList($this->notice, $this);
        } else {
            $nl = new ThreadedNoticeList($this->notice, $this, $this->userProfile);
        } 

        $cnt = $nl->show();
/*
        $this->pagination($this->page > 1,
                          $cnt > NOTICES_PER_PAGE,
                          $this->page,
                          'showclass',
                          array('nickname' => $this->group->nickname));
  */  }
    
	function showGroupFollowNotices()
    {
        $user = common_current_user();

        if (!empty($user) && $user->streamModeOnly()) {
            $nl = new NoticeList($this->notice, $this);
        } else {
            $nl = new ThreadedNoticeList($this->notice, $this, $this->userProfile);
        } 

        $cnt = $nl->showFollow();

        $this->pagination($this->page > 1,
                          $cnt > NOTICES_PER_PAGE,
                          $this->page,
                          'showclass',
                          array('nickname' => $this->group->nickname));
    }
    
    function showEmptyListMessage()
    {
    	// TRANS: Empty list message. %s is a user nickname.
    	$message = sprintf(_('This is the timeline for %s and friends but no one has posted anything yet.'), $this->userProfile->nickname) . ' ';
    
    	if (common_logged_in()) {
    		$current_user = common_current_user();
    		if ($this->userProfile->id === $current_user->id) {
    			// TRANS: Encouragement displayed on logged in user's empty timeline.
    			// TRANS: This message contains Markdown links. Keep "](" together.
    			$message .= _('Try subscribing to more people, [join a group](%%action.groups%%) or post something yourself.');
    		} else {
    			// TRANS: %1$s is user nickname, %2$s is user nickname, %2$s is user nickname prefixed with "@".
    			// TRANS: This message contains Markdown links. Keep "](" together.
    			$message .= sprintf(_('You can try to [nudge %1$s](../%2$s) from their profile or [post something to them](%%%%action.newnotice%%%%?status_textarea=%3$s).'), $this->userProfile->nickname, $this->user->nickname, '@' . $this->userProfile->nickname);
    		}
    	} else {
    		// TRANS: Encouragement displayed on empty timeline user pages for anonymous users.
    		// TRANS: %s is a user nickname. This message contains Markdown links. Keep "](" together.
    		$message .= sprintf(_('Why not [register an account](%%%%action.register%%%%) and then nudge %s or post a notice to them.'), $this->user->nickname);
    	}
    
    	$this->elementStart('div', 'guide');
    	$this->raw(common_markup_to_html($message));
    	$this->elementEnd('div');
    }

	function showPics()
    {
        $user = common_current_user();

        if (!empty($user) && $user->streamModeOnly()) {
            $nl = new NoticeList($this->notice, $this);
        } else {
            $nl = new ThreadedNoticeList($this->notice, $this, $this->userProfile);
            $cnt = $nl->showPics();
        } 

       $this->pagination(
                $this->page > 1, 
            	$cnt > NOTICES_PER_PAGE,
                $this->page, 
            	'showclass', array('nickname' =>$this->group->nickname,'id'=>1)
            );
    }

    /**
     * Get a list of the feeds for this page
     *
     * @return void
     */
    function getFeeds()
    {
        $url =
          common_local_url('grouprss',
                           array('nickname' => $this->group->nickname));

        return array(new Feed(Feed::JSON,
                              common_local_url('ApiTimelineGroup',
                                               array('format' => 'as',
                                                     'id' => $this->group->id)),
                              // TRANS: Tooltip for feed link. %s is a group nickname.
                              sprintf(_('Notice feed for %s group (Activity Streams JSON)'),
                                      $this->group->nickname)),
                    new Feed(Feed::RSS1,
                              common_local_url('grouprss',
                                               array('nickname' => $this->group->nickname)),
                              // TRANS: Tooltip for feed link. %s is a group nickname.
                              sprintf(_('Notice feed for %s group (RSS 1.0)'),
                                      $this->group->nickname)),
                     new Feed(Feed::RSS2,
                              common_local_url('ApiTimelineGroup',
                                               array('format' => 'rss',
                                                     'id' => $this->group->id)),
                              // TRANS: Tooltip for feed link. %s is a group nickname.
                              sprintf(_('Notice feed for %s group (RSS 2.0)'),
                                      $this->group->nickname)),
                     new Feed(Feed::ATOM,
                              common_local_url('ApiTimelineGroup',
                                               array('format' => 'atom',
                                                     'id' => $this->group->id)),
                              // TRANS: Tooltip for feed link. %s is a group nickname.
                              sprintf(_('Notice feed for %s group (Atom)'),
                                      $this->group->nickname)),
                     new Feed(Feed::FOAF,
                              common_local_url('foafgroup',
                                               array('nickname' => $this->group->nickname)),
                              // TRANS: Tooltip for feed link. %s is a group nickname.
                              sprintf(_('FOAF for %s group'),
                                       $this->group->nickname)));
    }

    function showAnonymousMessage()
    {
        if (!(common_config('site','closed') || common_config('site','inviteonly'))) {
            // TRANS: Notice on group pages for anonymous users for StatusNet sites that accept new registrations.
            // TRANS: %s is the group name, %%%%site.name%%%% is the site name,
            // TRANS: %%%%action.register%%%% is the URL for registration, %%%%doc.help%%%% is a URL to help.
            // TRANS: This message contains Markdown links. Ensure they are formatted correctly: [Description](link).
            $m = sprintf(_('**%s** is a user group on %%%%site.name%%%%, a [micro-blogging](http://en.wikipedia.org/wiki/Micro-blogging) service ' .
                'based on the Free Software [StatusNet](http://status.net/) tool. Its members share ' .
                'short messages about their life and interests. '.
                '[Join now](%%%%action.register%%%%) to become part of this group and many more! ([Read more](%%%%doc.help%%%%))'),
                     $this->group->getBestName());
        } else {
            // TRANS: Notice on group pages for anonymous users for StatusNet sites that accept no new registrations.
            // TRANS: %s is the group name, %%%%site.name%%%% is the site name,
            // TRANS: This message contains Markdown links. Ensure they are formatted correctly: [Description](link).
            $m = sprintf(_('**%s** is a user group on %%%%site.name%%%%, a [micro-blogging](http://en.wikipedia.org/wiki/Micro-blogging) service ' .
                'based on the Free Software [StatusNet](http://status.net/) tool. Its members share ' .
                'short messages about their life and interests.'),
                     $this->group->getBestName());
        }
        $this->elementStart('div', array('id' => 'anon_notice'));
        $this->raw(common_markup_to_html($m));
        $this->elementEnd('div');
    }

    

    function showSections()
    {
    	if (common_logged_in()) {
    		//$block = new DefaultProfileBlock($this);
    		//$block->show();
    		$this->showMemberList();
    	}
    }
    
    function showMemberList()
    {
    	$user = common_current_user();
    	if(!empty($user)){
    		if(!empty($_POST['cur_class']))
    		{
    			$default=$_POST['cur_class'];
    			$curclass=$default;
    			common_switch_class($default);
    		}
    		else
    		{
    			$curclass='';
    		}
    	 	$memberlist=new MemberList($this);
    		$memberlist->show();
    	}
    
    }
    
    function extraHead()
    {
        if ($this->page != 1) {
            $this->element('link', array('rel' => 'canonical',
                                         'href' => $this->group->homeUrl()));
        }
    }
}
 
 