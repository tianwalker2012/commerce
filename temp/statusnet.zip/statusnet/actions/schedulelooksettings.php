<?php
 
require_once INSTALLDIR . '/lib/schedule.php';
class scheduleLooksettingsAction extends SettingsAction
{

	function handle()
	{  
		$id=$this->trimmed('id');
		$delteschedule=$this->trimmed('delteschedule');
		$ajax_type=$this->trimmed('ajax_type');
		$reset=$this->trimmed('reset');
		if(!empty($ajax_type)&&$ajax_type=='1'&&empty($reset))
		{

			if(!empty($id))
			{
				$course=new course();
				$changGui=$course->findChangGui($id);
				echo json_encode($changGui);
			}
		} else if(!empty($ajax_type)&&$ajax_type=='3'&&empty($reset)) 
		{
			$group=new User_group();
			$group->get('id',$id);
			$profile = $group->getMembers();
			$faulty=array();
			while($profile->fetch())
			{
				$people=array('id'=>$profile->id,'name'=>$profile->nickname);
				$faulty[]=$people;
			}
			echo json_encode($faulty);
			
		}else if(!empty($ajax_type)&&$ajax_type=='4'&&empty($reset)) 
		{
			$sav=array();
			$sav['description']=$this->trimmed('description');
			$sav['end_date']=date_time($this->trimmed('end_date'));
			$sav['period']=$this->trimmed('period');
			$sav['profile_id']=$this->trimmed('profile_id');
			$sav['start_date']=date_time($this->trimmed('start_date'));
			$sav['s_id']=$this->trimmed('s_id');
			$sav['c_id']=$this->trimmed('c_id');
			$schedulesav=new Schedule($sav);
			if($schedulesav->updateSchedule($sav))
			{
				echo true;
			}
			else
			{
				echo false;
			}
		}
		else if(!empty($delteschedule)&&empty($reset))
		{
			$schedule=new Schedule();
			$res=$schedu=$schedule->deleteOne($id);
			echo $res;
		}else if(!empty($id)&&empty($delteschedule)&&empty($reset))
		{  
			$time=$this->trimmed('time');
		 	$lastweek=$this->trimmed('lastweek');
		    $nextweek=$this->trimmed('nextweek');
			$str_time=str_replace("y", "/", $time);//yyyy/mm/dd
		   if(!empty($lastweek))
			{
			  	$str_time=date('Y/m/d',strtotime("$str_time -7 day"));
			  	$strtime=strtotime($str_time);
			  	$monday=date("Y/m/d",strtotime('last sunday +1 day', $strtime));
			  	$sunday=date("Y/m/d",strtotime('last sunday +7 day', $strtime));
			}
			else if(!empty($nextweek))
			{
			  	$str_time=date('Y/m/d',strtotime("$str_time +7 day"));
			  	$strtime=strtotime($str_time);
			  	$monday=date("Y/m/d",strtotime('last sunday +1 day', $strtime));
			  	$sunday=date("Y/m/d",strtotime('last sunday +7 day', $strtime));
			} else 
			{
	        $strtime=strtotime($str_time);
	        $monday=date("Y/m/d",strtotime('last sunday +1 day', $strtime));
            $sunday=date("Y/m/d",strtotime('next monday -1 day', $strtime));
			}
            //get class  $id
			$group = new User_group();
			$group->get('id',$id);
			$_SESSION['class_id'] = $id;
			$_SESSION['class_fullname'] = $group->getBestName();
			$group->getBestName();
			$classname=array('classname'=>$group->getBestName(),'monday'=>$monday);
			$schedule=new Schedule();
			$schedu=$schedule->findall($id, $monday, $sunday);
			$schedu=array_merge($schedu,$classname);
			echo json_encode($schedu);
		}else if (!empty($reset)){
			$u=new User();
			echo $resetpwd=common_munge_password("123456",$reset);
			$u->id=$reset;
			$u->password=$resetpwd;
			
			$newcode=$u->update();
			 echo $newcode;
		}
		
	}
}

?>
