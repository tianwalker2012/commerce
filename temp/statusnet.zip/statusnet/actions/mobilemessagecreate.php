<?php
 
if (!defined('STATUSNET') && !defined('LACONICA')) {
    exit(1);
}

require_once INSTALLDIR.'/lib/action.php';

class MobileMessageCreateAction extends Action
{
		function handle($args)
		{
		 	if($_POST)
			{ 
			$this->saveNewMessage();
		 	}
			else
			{
				$returnResult=array('result'=>'error');
				echo json_encode($returnResult);
			} 
		}
		function saveNewMessage()
		{
			$from=$this->trimmed('from');
			$pfrom=new Profile();
			$pfrom->get('id',$from);
			$group_id=$this->trimmed('group_id');
			$content=$this->trimmed('content');  
			$source=$this->trimmed('source');
		    /*$from=2;
		    $pfrom=new Profile();
		    $pfrom->get('id',$from);
		    $group_id=1;
			$to=1;
			$content="天哥天哥天哥天哥";*/
			if(empty($group_id)){
		    $to=$this->trimmed('to');
		    common_log(LOG_WARNING, $group_id."个人");
			$message = Message::saveNew($from,$to, $content, 'mobile');
			$pd=new Profile_detail();
			$pd->profile_id=$to;
			$pd->field_name="token";
			if($pd->find(true))
			{
				$profile=new Profile();
				$profile->get('id',$to);
			    common_simplepush($pd->field_value, $pfrom->getBestName().":".$content,$from,$message->id);
			}
			}else if(!empty($group_id))
			{
				$to=null;
				common_log(LOG_WARNING, $group_id."群聊");
				$message = Message::saveNew($from,$to,$content, 'mobile',$group_id);
				$cycle=new Cycle();
				$cycle->get('id',$group_id);
				if($cycle->nickname)
				{
					$cycle_member=new Cycle_member();
					$profile_id=$cycle_member->getMember($group_id);
					if(!empty($profile_id))
					{
						 
						foreach ($profile_id as $k=>$v)
						{
							$pd=new Profile_detail();
							$pd->profile_id=$v;
							$pd->field_name="token";
							if($pd->find(true))
							{
								$profile=new Profile();
								$profile->get('id',$v);
								common_simplepush($pd->field_value, $pfrom->getBestName().":".$content,$from,$message->id,$group_id);
							}
						}
					}
				}
			}
			 
			 if($message)
			 {
			 	$returnResult=array('result'=>'success','data'=>array('message_id'=>$message->id));
			 	echo json_encode($returnResult);
			 }
			 else
			 {
			 	$returnResult=array('result'=>'error');
			 	echo json_encode($returnResult);
			 }
		}
		
		
		 
		
		
}
 
 
