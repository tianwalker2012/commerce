<?php
/**
 * StatusNet, the distributed open-source microblogging tool
 *
 * Change profile settings
 *
 * PHP version 5
 *
 * LICENCE: This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @category  Settings
 * @package   StatusNet
 * @author    Evan Prodromou <evan@status.net>
 * @author    Zach Copley <zach@status.net>
 * @author    Sarven Capadisli <csarven@status.net>
 * @copyright 2008-2009 StatusNet, Inc.
 * @license   http://www.fsf.org/licensing/licenses/agpl-3.0.html GNU Affero General Public License version 3.0
 * @link      http://status.net/
 */
require_once INSTALLDIR.'/lib/mangestulist.php';
if (!defined('STATUSNET') && !defined('LACONICA')) {
    exit(1);
}
/**
 * Change profile settings
 *
 * @category Settings
 * @package  StatusNet
 * @author   Evan Prodromou <evan@status.net>
 * @author   Zach Copley <zach@status.net>
 * @author   Sarven Capadisli <csarven@status.net>
 * @license  http://www.fsf.org/licensing/licenses/agpl-3.0.html GNU Affero General Public License version 3.0
 * @link     http://status.net/
 */
require_once INSTALLDIR.'/lib/mangelist.php';
class EditstusettingsAction extends SettingsAction
{
    /**
     * Title of the page
     *
     * @return string Title of the page
     */
	 
	
    function title()
    {
        // TRANS: Page title for profile settings.
        return _('编辑学生页面');
    }

    /**
     * Instructions for use
     *
     * @return instructions for use
     */
    function getInstructions()
    {
    	
    	
        // TRANS: Usage instructions for profile settings.
        return _('编辑学生信息');
    }
    /**
     * Content area of the page
     *
     * Shows a form for uploading an avatar.
     *
     * @return void
     */
    function showContent()
    { 
    	$updatestuinformation=$this->trimmed('updatestuinformation');
    	if(!empty($updatestuinformation))
    	{
    		$p_id=$updatestuinformation;
    		$fullname=$this->trimmed('editstufullname');
    		$oldrole=$this->trimmed('oldrole');
    		$newrole=$this->trimmed('editsturole');
    		$profile=new Profile();
    		$profile->get('id',$updatestuinformation);
    		$profile->fullname=$fullname;
    		$profile->update();
    		
    		//电子邮件不可以修改
    	/*	$email=$this->trimmed('editemail');
    		$user=new user();
    		$user->get('id',$updatestuinformation);
    		$user->email=$email;
    		$user->update();*/
    		
    		$kidname=$this->trimmed('editkidsname');
    		$stuphone=$this->trimmed('editstuphone');
    		$p_detail=new Profile_detail();
    		$p_detail->profile_id="$updatestuinformation";
    		$p_detail->find(true);
    		
    		$flag=false;
    		while($p_detail->fetch()){
	    		if($p_detail->field_name=='kids')
	    		{
		    		$p_detail->field_name='kids';
		    		$p_detail->field_value=$kidname;
		    	    $p_detail->update();
		    	    $flag=true;
		    	    break;
	    		}
    		 }
    		 
    		 if(!$flag)
    		 {
    		 	$p_detail->created=common_sql_now();
    		 	$p_detail->profile_id=$updatestuinformation;
    		 	$p_detail->field_name='kids';
    		 	$p_detail->field_value=$kidname;
    		 	$p_detail->insert();
    		 }
    		 
    	    $phone_detail=new Profile_detail();
    	    $phone_detail->profile_id="$updatestuinformation";
    	    $phone_detail->field_name='phone';
    	    $phone_detail->find(true);
    	    
    	    $flag=false;
    	    while($p_detail->fetch()){
	    		if($p_detail->field_name=='phone')
	    		{
		    		$p_detail->field_name='phone';
		    		$p_detail->field_value=$stuphone;
		    	    $p_detail->update();
		    	    $flag=true;
		    	    break;
	    		}
    		}
    		
    		if(!$flag)
    		 {
    		 	$p_detail->created=common_sql_now();
    		 	$p_detail->profile_id=$updatestuinformation;
    		 	$p_detail->field_name='phone';
    		 	$p_detail->field_value=$stuphone;
    		 	$p_detail->insert();
    		 }
    		 
    		 // @weimu: when user role changes ...
    		 if ($newrole != $oldrole) {
    		 	// revoke all existing roles
    		 	$profile_role=new Profile_role();
    		 	$profile_role->profile_id=$p_id;
    		 	$profile_role->delete();
    		 	
    		 	// add new roles based on user selection
    		 	switch ($newrole)
    		 	{
    		 		case "role_parents":
    		 			$profile->grantRole(Profile_role::PARENTS);
    		 			break;
    		 		case "role_faculty":
    		 			$profile->grantRole(Profile_role::FACULTY);
    		 			break;
    		 		case "role_coursemaster":
    		 			$profile->grantRole(Profile_role::FACULTY);
    		 			$profile->grantRole(Profile_role::COURSEMASTER);
    		 			break;
    		 		case "role_schoolmaster":
    		 			$profile->grantRole(Profile_role::FACULTY);
    		 			$profile->grantRole(Profile_role::SCHOOLMASTER);
    		 			break;
    		 		case "role_moderator":
    		 			$profile->grantRole(Profile_role::FACULTY);
    		 			$profile->grantRole(Profile_role::MODERATOR);
    		 			break;
    		 		default:
    		 	}
    		 }
    	}
       $mangestulist=new MangeStuList($this,'user');
       $mangestulist->showContentEdit();
    }

    
    /**
     * Handle a post
     *
     * Validate input and save changes. Reload the form with a success
     * or error message.
     *
     * @return void
     */
    function handlePost()
    { }

    function nicknameExists($nickname)
    {
        $user = common_current_user();
        $other = User::staticGet('nickname', $nickname);
        if (!$other) {
            return false;
        } else {
            return $other->id != $user->id;
        }
    }

    function showAside() {
        $user = common_current_user();

        $this->elementStart('div', array('id' => 'aside_primary',
                                         'class' => 'aside'));

        $this->elementStart('div', array('id' => 'account_actions',
                                         'class' => 'section'));
        $this->elementStart('ul');
        if (Event::handle('StartProfileSettingsActions', array($this))) {
            if ($user->hasRight(Right::BACKUPACCOUNT)) {
                $this->elementStart('li');
                $this->element('a',
                               array('href' => common_local_url('backupaccount')),
                               // TRANS: Option in profile settings to create a backup of the account of the currently logged in user.
                               _('Backup account'));
                $this->elementEnd('li');
            }
            if ($user->hasRight(Right::DELETEACCOUNT)) {
                $this->elementStart('li');
                $this->element('a',
                               array('href' => common_local_url('deleteaccount')),
                               // TRANS: Option in profile settings to delete the account of the currently logged in user.
                               _('Delete account'));
                $this->elementEnd('li');
            }
            if ($user->hasRight(Right::RESTOREACCOUNT)) {
                $this->elementStart('li');
                $this->element('a',
                               array('href' => common_local_url('restoreaccount')),
                               // TRANS: Option in profile settings to restore the account of the currently logged in user from a backup.
                               _('Restore account'));
                $this->elementEnd('li');
            }
            Event::handle('EndProfileSettingsActions', array($this));
        }
        $this->elementEnd('ul');
        $this->elementEnd('div');
        $this->elementEnd('div');
    }
}
