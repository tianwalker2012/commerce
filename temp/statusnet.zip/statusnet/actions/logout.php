<?php
/**
 * Logout action.
 *
 * PHP version 5
 *
 * @category Action
 * @package  StatusNet
 * @author   Evan Prodromou <evan@status.net>
 * @author   Robin Millette <millette@status.net>
 * @license  http://www.fsf.org/licensing/licenses/agpl.html AGPLv3
 * @link     http://status.net/
 *
 * StatusNet - the distributed open-source microblogging tool
 * Copyright (C) 2008, 2009, StatusNet, Inc.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

if (!defined('STATUSNET') && !defined('LACONICA')) {
    exit(1);
}

/**
 * Logout action class.
 *
 * @category Action
 * @package  StatusNet
 * @author   Evan Prodromou <evan@status.net>
 * @author   Robin Millette <millette@status.net>
 * @license  http://www.fsf.org/licensing/licenses/agpl.html AGPLv3
 * @link     http://status.net/
 */
class LogoutAction extends Action
{
    /**
     * This is read only.
     *
     * @return boolean true
     */
    function isReadOnly($args)
    {
        return false;
    }

    /**
     * Class handler.
     *
     * @param array $args array of arguments
     *
     * @return nothing
     */
    function handle($args)
    {
        parent::handle($args);
        if (!common_logged_in()) {
            // TRANS: Error message displayed when trying to perform an action that requires a logged in user.
            $this->clientError(_('Not logged in.'));
        } else {
            if (Event::handle('StartLogout', array($this))) {
                $this->logout();
            }
            Event::handle('EndLogout', array($this));

            if (common_config('singleuser', 'enabled')) {
                $user = User::singleUser();
                common_redirect(common_local_url('showstream',
                                                 array('nickname' => $user->nickname)));
            } else {


            	$pageURL = 'http';
            	
            	/*
            	if ($_SERVER["HTTPS"] == "on")
            	{
            		$pageURL .= "s";
            	}
            	*/
            	$pageURL .= "://";
            		
            	if ($_SERVER["SERVER_PORT"] != "80")
            	{
            		$pageURL .= $_SERVER["SERVER_NAME"] . ":" . $_SERVER["SERVER_PORT"] . $_SERVER["REQUEST_URI"];
            	}
            	else
            	{
            		$pageURL .= $_SERVER["SERVER_NAME"] . $_SERVER["REQUEST_URI"];
            	}
            	$index=mb_strpos($pageURL,'/index.php');
            	$urilogin="";
            	if($index!=false)
            	{
            		$urilogin=mb_substr($pageURL,0,$index);
            		$urilogin.="/login.html";
            	}
            	else
            	{
            		$urilogin=$pageURL."/login.html";
            		//echo "<script>//alert('".$urilogin."');</script>";
            	}
            	//echo "<script>//alert('".$urilogin."');</script>";
            	echo "<script>window.location.href='".$urilogin."';</script>";
            	
            	 //common_redirect(common_local_url('public'), 303);
            }
        }
    }

    function logout()
    {
        common_set_user(null);
        common_real_login(false); // not logged in
        common_forgetme(); // don't log back in!
    }
}
