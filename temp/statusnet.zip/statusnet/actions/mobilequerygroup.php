<?php
/**
 * StatusNet - the distributed open-source microblogging tool
 * Copyright (C) 2008-2011, StatusNet, Inc.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @category Actions
 * @package  Actions
 * @author   Adrian Lang <mail@adrianlang.de>
 * @author   Brenda Wallace <shiny@cpan.org>
 * @author   Brion Vibber <brion@pobox.com>
 * @author   Craig Andrews <candrews@integralblue.com>
 * @author   Evan Prodromou <evan@status.net>
 * @author   Jeffery To <jeffery.to@gmail.com>
 * @author   Meitar Moscovitz <meitarm@gmail.com>
 * @author   Mike Cochrane <mikec@mikenz.geek.nz>
 * @author   Robin Millette <millette@status.net>
 * @author   Sarven Capadisli <csarven@status.net>
 * @author   Siebrand Mazeland <s.mazeland@xs4all.nl>
 * @author   Zach Copley <zach@status.net>
 * @copyright 2009 Free Software Foundation, Inc http://www.fsf.org
 * @license  GNU Affero General Public License http://www.gnu.org/licenses/
 * @link     http://status.net
 */


class MobileQueryGroupAction extends Action
{
		function handle($args)
		{
			$this->QueryGroup();
		}
		function QueryGroup()
		{
		 	$id=$this->trimmed('id');
		 	$profile=new Profile();
		 	$profile->id=$id;
		 	$a=$profile->getGroups();
		 	$class_id=array();
		 	foreach ((array)$a as $k=>$v)
		 	{
		 		if(is_array($v)){
		 			foreach ($v as $k=>$b)
		 			{
		 			 $class_id[]=$b->id;
		 			}
		 		}
		 	}
		 	
			
			$group=array();
			foreach ($class_id as $k=>$v)
			{
				$user_group=new User_group();
		    	$user_group->id=$v;
		    	if($user_group->find(true))
		    	{ 
		    		$group[]=array('id'=>$user_group->id,
				    				'name'=>$user_group->fullname,
				    				'created'=>$user_group->created);
		    		
		    	} 
			}
		   if($group)
			{
				$returnResult=array('result'=>'success',
						            'data'=>$group
						                );
				echo json_encode($returnResult);
			}
			else
			{
				$returnResult=array('result'=>'error');
				echo json_encode($returnResult);
			}
		}
}
 
 
