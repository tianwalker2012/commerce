<?php
/**
 * StatusNet - the distributed open-source microblogging tool
 * Copyright (C) 2008-2011, StatusNet, Inc.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @category Actions
 * @package  Actions
 * @author   Adrian Lang <mail@adrianlang.de>
 * @author   Brenda Wallace <shiny@cpan.org>
 * @author   Brion Vibber <brion@pobox.com>
 * @author   Craig Andrews <candrews@integralblue.com>
 * @author   Evan Prodromou <evan@status.net>
 * @author   Jeffery To <jeffery.to@gmail.com>
 * @author   Meitar Moscovitz <meitarm@gmail.com>
 * @author   Mike Cochrane <mikec@mikenz.geek.nz>
 * @author   Robin Millette <millette@status.net>
 * @author   Sarven Capadisli <csarven@status.net>
 * @author   Siebrand Mazeland <s.mazeland@xs4all.nl>
 * @author   Zach Copley <zach@status.net>
 * @copyright 2009 Free Software Foundation, Inc http://www.fsf.org
 * @license  GNU Affero General Public License http://www.gnu.org/licenses/
 * @link     http://status.net
 */


class MobileMessageQueryAction extends Action
{
		function handle($args)
		{
			$this->QueryMessage();
		}
		function QueryMessage()
		{  
			$oneid=$this->trimmed('oneid');
			$otherid=$this->trimmed('otherid');
			$start=$this->trimmed('start');
			if($start<0)
			{
				$start=0;
			}
			$limit=$this->trimmed('limit');
		      
		    	$return=array();
		    	$message=new Message();
    	    	common_link_db();
    	         $qry ="select *, " .
    	    	" ( case when from_profile>to_profile  " .
    	    	" then concat( from_profile,'-',to_profile ) " .
    	    	" else " .
    	    	" concat ( to_profile,'-',from_profile ) ".
    	    	" end " .
    	    	") as f_t " .
    	    	"from message m " .
    	    	"WHERE (from_profile= " .$oneid.
    	    	" AND to_profile= " .$otherid.
    	    	") or (to_profile= " .$oneid.
    	    	" and from_profile= " .$otherid.
    	    	" ) ORDER BY m.created DESC ".
    	    	" LIMIT  ". $start ." , ". $limit . "   ";
    	    	  $result=mysql_query($qry);
    	    	  	while($arr=mysql_fetch_array($result))
    	    	  	{   
    	    	  		$return[]=array('mesid'=>$arr['id'],
		    	    	  				'from'=>$arr['from_profile'],
		    	    	  				'to'=>$arr['to_profile'],
		    	    	  				'content'=>$arr['content'],
		    	    	  				'source'=>$arr['source'],
		    	    	  				'created'=>$arr['created'],
    	    	  		);
    	    	  	}
		    
		    if($return)
		    {
		    	$returnResult=array('result'=>'success',
		    			'data'=>$return
		    	);
		    	echo json_encode($returnResult);
		    }
		    else
		    {
		    	$returnResult=array('result'=>'error');
		    	echo json_encode($returnResult);
		    }
		    
		    
		 }
}
 
 
