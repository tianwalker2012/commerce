<?php
if (!defined('STATUSNET') && !defined('LACONICA')) { exit(1); }

$config['site']['name'] = 'JXHD2';
$config['site']['path'] = 'statusnet';

/* 
$config['site']['server'] = 'localhost';
// enable debugging logs
$config['site']['logdebug'] = true;
*/

$config['site']['server'] = 'localhost';
// enable debugging logs
$config['site']['logdebug'] = false;

$config['site']['logfile'] = 'statusnet.log';

$config['db']['database'] = 'mysqli://statusnet:songeast123!@localhost/statusnet';

$config['db']['type'] = 'mysql';

$config['site']['profile'] = 'public';

// disable users from seeing and changing location settings
$config['location']['sharedefault'] = false;
$config['location']['share'] = 'never';

// set default language to Chinese Sipmlified
$config['site']['language'] = 'zh-cn';
$config['site']['langdetect'] = false;

// set default timezone to Asia/Shanghai
$config['site']['timezone'] = 'Asia/Shanghai';

// disable backpup/restore by users
$config['profile']['restore'] =  false;
$config['profile']['backup'] =  false;


$config['performance']['high'] = true;
