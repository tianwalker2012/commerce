<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" type="text/css" href="./theme/base.css">
<script  type="text/javascript" src="./js/jquery-1.8.2.js"></script>

</head>
<body>    

<div class="download">
<h1>家校互动手机客户端下载</h1>
<div class="ios">
<a href="itms-services://?action=download-manifest&url=http://www.songeast.com.cn/statusnet/downloads/distribution_desc.plist">
</a>
</div>
 <div class="android">
<a href="./downloads/interactive.apk">
 </a>
</div>
 </div>
</body>
</html>
<script type="text/javascript">

/*
$(".android").mouseover(function(){
	$(".android").css("background","url(./images/mobile_download.png -47px 0px;)");
});
*/
</script>