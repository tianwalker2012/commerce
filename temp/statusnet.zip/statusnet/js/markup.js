//给班级添加下拉列表
$(function(){
	
	$(".myform").submit(function(){
		if(confirm("确定要删除吗"))
		{ }
		else
		{     
			alert("没有删除");
			return false;
			 
		}
	})
	
	$(".submit_save_information").mouseover(function(){
		$(".submit_save_information").css('background-color','#FB6913');
	})
	$(".submit_save_information").mouseout(function(){
		$(".submit_save_information").css('background-color','#FD8842');
	})
	var t = $(".class_bugs");
	t.hide();
	$(".uboxstyle").click(function(){
		t.show();
	});
	$(".action_class").click(function(){
		t.show();
	});
});

$(document).bind("click",function(e){
	var target  = $(e.target);
	if((target.attr("class") != "uboxstyle")&&(target.attr("class") != "action_class")){
    	$(".class_bugs").hide();
	}
});

//课程管理里的时间选择器
$(function(){
	$("#datepicker").datepicker();
	$("#from").datepicker({
		onClose: function(selectedDate) {
            $("#to").datepicker( "option", "minDate", selectedDate );
        }
	});
	$("#to").datepicker({
		onClose: function(selectedDate) {
			$("#from").datepicker("option","maxDate",selectedDate);
		}
	});
	$("#the_date").datepicker();
});


//给悄悄话添加动态效果
function secret_talk(pointer){

	// @weimu: force the string pattern of to-selector choices as <prefix>:<value>:<type>
	var param = pointer.value.split(":");
	if(param[2] == "message"){
		$("#receiver").html("");
		$("#receiver").hide("slow");
		$(".talk_secret").css({visibility:"visible",color:"#3E3E8C",cursor:"pointer"});
		$(".talk_secret").mouseover(function(){
			$(this).css({color:"blue"});
		});
		$(".talk_secret").mouseout(function(){
			$(this).css({color:"#3E3E8C"});
		});
		$(".talk_secret").unbind("click");
		$(".talk_secret").click(
			function(){
				add_span(this);
			}
		);
		$(pointer).attr("onclick","");
	}else{
		$("#secret").attr("onclick","secret_talk(this);");
		$(".talk_secret").css({visibility:"hidden",color:"#3E3E8C",cursor:"default"});
		$(".talk_secret").unbind("click");
		$("#receiver").html("");
		$("#receiver").hide("slow");
	}
}
//关闭发送对象函数
function talk_close(i,ids){
	$(i).parent("span").remove();
	$("."+ids).remove();
	$("#num").val($("#num").val()-1);
	$("#"+ids).css({color:"#3E3E8C",cursor:"pointer"});
	$("#"+ids).mouseover(function(){
			$(this).css({color:"blue"});
	});
	$(".talk_secret").mouseout(function(){
		$(this).css({color:"#3E3E8C"});
	});
	$("#"+ids).click(
		function(){
			add_span(this);
		}
	);
	if($("#receiver").find("span").length == 0){
  		$("#receiver").empty();
		$("#receiver").hide("slow");
	}
}

//添加span标签的函数
function add_span(s){
	if($("#receiver").html()==""){
		$("#receiver").show();
		$("#receiver").css({border:"1px solid #FB6104"});
	}
	$(s).css({color:"#999",cursor:"default"});

	$(s).mouseover(function(){
		$(s).css({color:"#999"});
	});
	$(s).mouseout(function(){
		$(s).css({color:"#999"});
	});
	$(s).unbind("click");
	var ids = $(s).attr("id");
	var names = $(s).attr("name");
	if (typeof($("#num").val())=="undefined") {
	  $("<input type='hidden' name='num' id='num' value='1' />").appendTo("#receiver");
	}else{
	  var t = $("#num").val();
	  t = parseInt(t) + 1;
	  $("#num").val(t);
	}
	$("<span>"+names+"<a href=\"javascript:void(0);\" onclick=\"talk_close(this,'"+ids+"');return false;\" class=\"ui-icon ui-icon-circle-close\"></a></span>").appendTo("#receiver");
	$("<input type='hidden' name='profile_id"+$("#num").val()+"' class='"+ids+"' value='"+ids+"' />").appendTo("#receiver");
}