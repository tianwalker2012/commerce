$(function(){
 	 var datatime=$('#gettime').text();
	 var time=datatime.replace(/\//g,'y')
	 var id=$('#chooseclass').val();
	  $.get("../schedulelooksettings/"+id+"/"+time,function(data){
			 for(var i=0;i<=10;i++)
				 {
				   for(var j=0;j<=7;j++)
					   {
					  $('#td'+i+j).text("");	
					  $('#td'+i+j).parent().css("background-color","");
					   }
				 }
			 var result=eval("("+data+")");
			 $('#gettime').text(result.monday);
			 $('#getname').text("班级："+result.classname);
			 $.each(result ,function(i){
				 $('#td'+result[i].period+result[i].start_date).text(result[i].course_id);	
				 $('#td'+result[i].period+result[i].start_date).attr('href','../viewschedulesettings/'+result[i].c_id+"/"+result[i].id);	
				 $('#td'+result[i].period+result[i].start_date).parent().css('background-color','#D9E1F2');	
				 }) 
		  })
		  
		  
			$("input[name='lastweek']").click(function(){ 
				 var datatime=$('#gettime').text();
				 var time=datatime.replace(/\//g,'y')
				 var id=$('#chooseclass').val();
				  $.get("../schedulelooksettings/"+id+"/"+time+"?lastweek=1",function(data){
						 for(var i=0;i<=10;i++)
							 {
							   for(var j=0;j<=7;j++)
								   {
									 $('#td'+i+j).text("");
									 $('#td'+i+j).parent().css("background-color","");
								   }
							 }
						 var result=eval("("+data+")");
						 $('#gettime').text(result.monday);
						 $('#getname').text("班级："+result.classname);
						 $.each(result ,function(i){
							 $('#td'+result[i].period+result[i].start_date).text(result[i].course_id);	
							 $('#td'+result[i].period+result[i].start_date).attr('href','../viewschedulesettings/'+result[i].c_id+"/"+result[i].id);	
							 $('#td'+result[i].period+result[i].start_date).parent().css('background-color','#D9E1F2');	
						 }) 
					  })
			})
			
			$("input[name='nextweek']").click(function(){ 
				var datatime=$('#gettime').text();
				var time=datatime.replace(/\//g,'y')
				var id=$('#chooseclass').val();
				$.get("../schedulelooksettings/"+id+"/"+time+"?nextweek=1",function(data){
					for(var i=0;i<=10;i++)
					{
						for(var j=0;j<=7;j++)
						{
							$('#td'+i+j).text("");			 
							$('#td'+i+j).parent().css("background-color","");			 
						}
					}
					var result=eval("("+data+")");
					$('#gettime').text(result.monday);
					$('#getname').text("班级："+result.classname);
					$.each(result ,function(i){
						 $('#td'+result[i].period+result[i].start_date).text(result[i].course_id);	
						 $('#td'+result[i].period+result[i].start_date).attr('href','../viewschedulesettings/'+result[i].c_id+"/"+result[i].id);	
						 $('#td'+result[i].period+result[i].start_date).parent().css('background-color','#D9E1F2');	
					}) 
				})
			})

			 
			$("input[name='ajaxsubmit']").click(function(){ 
				  var datatime=$('#datepicker').val();
				  datatime=datatime.split('/')[2]+"/"+datatime.split('/')[0]+"/"+datatime.split('/')[1];
				  var time=datatime.replace(/\//g,'y')
				  var id=$('#chooseclass').val();
					 $.get("../schedulelooksettings/"+id+"/"+time,function(data){
						 for(var i=0;i<=10;i++)
							 {
							   for(var j=0;j<=7;j++)
								   {
									 $('#td'+i+j).text("");
									 $('#td'+i+j).parent().css("background-color","");
								   }
							 }
						 var result=eval("("+data+")");
						 $('#gettime').text(result.monday);
						 $('#getname').text("班级："+result.classname);
						 $.each(result ,function(i){
							 $('#td'+result[i].period+result[i].start_date).text(result[i].course_id);	
							 $('#td'+result[i].period+result[i].start_date).attr('href','../viewschedulesettings/'+result[i].c_id+"/"+result[i].id);	
							 $('#td'+result[i].period+result[i].start_date).parent().css('background-color','#D9E1F2');	
						 }) 
					  })
			})

		  
});