	$(function() {
		
		
		$('#extprofile-fullname').blur(function(){
			var a= $('#extprofile-fullname').val();
			if(a.length>=4)
				{
				alert("名字长度不可以大于四");
				}
		})
		$('#tabs').tabs({active:1, collapsible:true});
		$( "#class-selector" )
			.button({
				icons: {
					primary: "ui-icon-home",
					secondary: "ui-icon-triangle-1-s"
	            }
    	    })
			.click(function() {
                    var menu = $( this ).parent().next().show().position({
                        my: "left top",
                        at: "left bottom",
                        of: this
                    });
                    $( document ).one( "click", function() {
                        menu.hide();
                    });
                    return false;
                })
                .parent()
                    .buttonset()
                    .next()
                        .hide()
                        .menu();
 

})




 
	 
	
	
 
