$(function(){
  $('#container').masonry({
    // options 
   itemSelector: '.group_item',
	columnWidth: 100   
  });
})