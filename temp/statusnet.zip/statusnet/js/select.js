$(function(){ 
	     //全选
	     $(".CheckedAll").click(function(){ 
				$("[name='remove[]']:checkbox").attr("checked", this.checked );
		 });
		  $("[name='remove[]']:checkbox").click(function(){ 
	      $tmp=$("[name='remove[]']:checkbox"); 
		 $('.CheckedAll').attr('checked',$tmp.length==$tmp.filter(':checked').length);
		 });
	
});