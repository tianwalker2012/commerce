$(function(){ 
	$('#select_course_type').change(function(){
		  var index=$('#select_course_type').val();
		  if(index=='1')
	      {
			  $('#data_type_1').show();
			  $('#data_type_3').hide();
			  $('#repeat_class').show();
	      }
		  else if(index=='3')
		  { 
			  $('#data_type_1').hide();
			  $('#data_type_3').show();
			  $('#repeat_class').hide();
		  }

		var course_id=$('#select_course_type').val();
		$.get("../schedulelooksettings/"+course_id+"/2010y01y01?ajax_type=1",function(data){
			var result=eval("("+data+")");
			$("#select_course_name").empty();
			if(result=='')
			{
		       $("#select_course_name").append("<option value='0'>没有课程</option>"); 
			}else{
		       $.each(result ,function(i){
		       $("#select_course_name").append("<option value="+result[i].id1+">"+result[i].nickname1+"</option>"); 
		       }) 
			}
		  })
	})
	
$("#select_class_name").change(function(){
		var num_id=$('#select_class_name').val();
		$.get("../schedulelooksettings/"+num_id+"/2010y01y01?ajax_type=3",function(data){
		   var result=eval("("+data+")");
		   $("#select_teacher").empty();
		   if(result=='')
		 {
		  $("#select_course_name").append("<option value='0'>没有老师</option>"); 
			}else{
		   $.each(result ,function(i){
		   $("#select_teacher").append("<option value="+result[i].id+">"+result[i].name+"</option>"); 
		       })
			 }
		  })
})
});
$(function(){ 
	$("input[name='save_sch']").click(function(){ 
		 var profie_id=$('#select_course_name').val();
		 var period=$('#weekend').val();
		 var start_date=$('#starttime').val();
		 var end_date=$('#endtime').val();
		 var description=$('#descript').val();
		 var s_id=$('#s_id').val();
		 var c_id=$('#c_id').val();
		 var num_id="1";
		  if(confirm("确定要保存吗？"))
			{
			  $.get("../../schedulelooksettings/"+num_id+"/2010y01y01?ajax_type=4&profile_id="+profie_id+"&period="+period+"&start_date="+start_date+"&end_date="+end_date+"&description="+description+"&c_id="+c_id+"&s_id="+s_id,function(data){
					 if(data)
						 {
						 alert("更新成功");
						 }
					 else
					 	{
						 alert("更新成功");
					 	}
					
				 })
			}
	})

});
$(function(){ 
	$("#starttime").datepicker();
	$("#endtime").datepicker();
})
 

$(function(){ 
	$("input[name='schedule_remove']").click(function(){ 
		var id=$('#sch_id').val();
		var time="2012y01y01";
		 
		  if(confirm("确定要删除吗？"))
			{
			 $.get("../../schedulelooksettings/"+id+"/"+time+"?delteschedule=1",function(data){
				 if(data)
					 {
					 alert("删除成功");
					 window.location.href="../../manageschedulesettings/1"		
					 }
				 else
				 	{
					 alert("没有删除");
				 	}
				})
			} 
		 
	})
});

$(function(){
	$("#reset").click(function(){
		var pwdid=$("#resetcode").val();
		var time="11y11y2000";
		 $.get("../../settings/schedulelooksettings/"+pwdid+"/"+time+"?reset="+pwdid,function(data){
			if(data)
				{
				
				alert("修改成功");
				}
			else
			{
				alert("修改失败");
			}
		 })
		  });
});
 
 